// libs
const cron = require('node-cron');
const moment = require('moment');
const mongoose = require('mongoose');

// models
const leadResponsesModel = require('../models/leadResponses');
const MailScheduleModel = require('../models/MailSchedule');
const AutoReplyModel = require('../models/automaticReply');
const mailboxesModel = require('../models/mailboxes');

// utils
const { sendEmail } = require('../utils/GoogleUtils.cjs');

async function getSenderEmailToRefreshTokenMap(senderEmails) {
    try {
        const mailboxesItems = await mailboxesModel.find({senderEmail: { $in: senderEmails } }).select('senderEmail provider_data').lean();

        // Create a map where key is senderEmail and value is provider_data.refresh_token
        const emailTokenMap = mailboxesItems.reduce((map, item) => {
            if (item.senderEmail && item.provider_data && item.provider_data.refresh_token) {
                map[item.senderEmail] = item.provider_data.refresh_token;
            }
            return map;
        }, {});

        return emailTokenMap;

    } catch (error) {
        console.error("Error retrieving data:", error);
        return null;
    }
}

const markEmailsAsReleased = async (idArray) => {

    if (!idArray?.length) {
        return null;
    }

    try {
        const objectIdArray = idArray.map(id => mongoose.Types.ObjectId(id));

        await MailScheduleModel.updateMany(
            { _id: { $in: objectIdArray } },
            { $set: { IsRelease: true } }
        );
    } catch(err) {
        console.error('Error updating IsRelease:', err);
    } finally {
        return null;
    }
}

const updateLeadResponsesInBulk = async (leadResponseUpdates) => {

    if (!leadResponseUpdates?.length) {
        return null;
    }

    try {
        await leadResponsesModel.bulkWrite(leadResponseUpdates);

    } catch(err) {
        console.error('Error updating lead responses:', err);
    } finally {
        return null;
    }
}

const updateAutoRepliesInBulk = async (autoReplyUpdates) => {

    if (!autoReplyUpdates?.length) {
        return null;
    }

    try {
        await AutoReplyModel.bulkWrite(autoReplyUpdates);

    } catch(err) {
        console.error('Error updating auto replies:', err);
    } finally {
        return null;
    }
}

async function outOfOfficeCronJob() {
    console.log('running cron job...!');
    const currentTime = Date.now(); // Current timestamp in milliseconds
    const momentDate1 = moment(currentTime).startOf('day');
    const momentDate2 = moment(currentTime).endOf('day');

    const mailScheduleItems = await MailScheduleModel.find({
        releaseTime: { $gte: momentDate1, $lte: momentDate2 },
        IsRelease: false
    }).lean();

    const senderEmails = mailScheduleItems.map(item => item?.from ?? '');
    const senderEmailToRefreshTokenMap = await getSenderEmailToRefreshTokenMap(senderEmails);

    const idArray = [];
    const leadResponseUpdates = [];
    const autoReplyUpdates = [];
    const MAIL_SCHEDULE_BATCH_SIZE = 2;

    for (let i = 0; i < mailScheduleItems.length; i += MAIL_SCHEDULE_BATCH_SIZE) {
        const batch = mailScheduleItems.slice(i, i + MAIL_SCHEDULE_BATCH_SIZE);

        // Process each batch in parallel but handle errors individually
        await Promise.all(batch.map(async (data) => {
            try {
                if (data.from) {
                    const sentAutoReply = await sendEmail({
                        refreshToken: senderEmailToRefreshTokenMap[data.from],
                        to: data?.to,
                        subject: data?.subject,
                        message: data?.message,
                        threadId: data?.threadId,
                        cc: data?.cc,
                        bcc: data?.bcc,
                        messageId: data?.messageId,
                    });

                    if (sentAutoReply) {
                        // Push relevant data for batch updates
                        idArray.push(data._id);

                        // Prepare leadResponse update
                        const leadResponse = await leadResponsesModel.findById(data.leadResponseId).lean();
                        if (leadResponse) {
                            const conversation = {
                                email: data?.to,
                                senderEmail: data?.from,
                                date: new Date().toISOString(),
                                cc: data?.cc,
                                subject: data?.subject,
                                messageId: data?.messageId,
                                body: data?.message,
                            };

                            leadResponseUpdates.push({
                                updateOne: {
                                    filter: { _id: mongoose.Types.ObjectId(leadResponse._id) },
                                    update: {
                                        $push: { conversations: conversation, cc: data?.cc },
                                        $set: { body: leadResponse.body + (data?.message ?? '') },
                                    },
                                },
                            });

                            // Prepare autoReply update
                            autoReplyUpdates.push({
                                updateOne: {
                                    filter: { threadId: data?.threadId },
                                    update: {
                                        $setOnInsert: {
                                            threadId: data?.threadId,
                                            campaignId: leadResponse?.campaignId,
                                            leadId: leadResponse?.leadId,
                                            leadResponseId: leadResponse?._id,
                                        },
                                    },
                                    upsert: true,
                                    setDefaultsOnInsert: true,
                                },
                            });
                        }
                    }
                }
            } catch (error) {
                console.error(`Error processing mail schedule item ${data._id}\n`, error);
            } finally {
                return null;
            }
        }));
    }

    await markEmailsAsReleased(idArray);
    await updateLeadResponsesInBulk(leadResponseUpdates);
    await updateAutoRepliesInBulk(autoReplyUpdates);
}

const mailScheduleCron = async () => {
    cron.schedule('0 12 * * 0', async () => {
        try {
            await outOfOfficeCronJob()
        } catch(err) {
            console.error('error running cron job', err)
        }
    })
}

module.exports = {
    mailScheduleCron,
}
