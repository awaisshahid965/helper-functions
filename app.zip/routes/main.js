const express = require('express');
const router = express.Router();
require('../controllers/campagins');

// router.post('/leadRepliesToMailbox', campaginsController.leadRepliesToMailbox);

module.exports = router;
