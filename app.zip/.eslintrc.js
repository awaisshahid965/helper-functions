module.exports = {
    parser: 'babel-eslint',
    plugins: ['es6-recommended'],
    rules: {
      'es6-recommended/imports': 2,
      'es6-recommended/node': 2,
    },
  };
  