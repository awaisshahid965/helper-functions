const { default: axios } = require('axios');

const GPT_ENDPOINT = "https://b2brocket-salesgpt.openai.azure.com/openai/deployments/gpt-35-salesgpt/chat/completions?api-version=2024-02-15-preview"

class GptChatClient {
    constructor() {}

    _createPromptConfiguration(prompts, options = {}) {
        return {
            model: "gpt-35-salesgpt",
            messages: prompts,
            stream: false,
            temperature: 0.5,
            max_tokens: 50,
            top_p: 0.85,
            frequency_penalty: 0,
            presence_penalty: 0,
            stop: ["-- Prompt Output --"],
            ...options,
        }
    }

    _constructRequestHeaders() {
        return {
            headers: {
              "Content-Type": "application/json",
              "api-key": `${process.env.OPEN_AI_API_KEY}`,
            },
        }
    }

    async sendPromptsToGpt(prompts, options) {
        try {
            const config = this._createPromptConfiguration(prompts, options);
            const headers = this._constructRequestHeaders();
            const { data } = await axios.post(GPT_ENDPOINT, config, headers)
            return data
        } catch(error) {
            console.log(error)
            throw new Error(error.message ?? '')
        }
    }
}

module.exports = new GptChatClient()