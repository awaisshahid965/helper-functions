const Bull = require('bull');
const Redis = require('ioredis');
const path = require('path');
const redisHost = 'eewebhook.redis.cache.windows.net';
const redisPort = 6380;
const redisPassword = 'PAXjJbidMSviMy7qcvBJAURBZh65hRt25AzCaMDStlQ=';

// Redis configuration
const redisConfig = {
  host: redisHost,
  port: redisPort,
  password: redisPassword,
  tls: {},
};

const redisClient = new Redis(redisConfig);

redisClient.on('connect', () => {
  console.log('Connected to Azure Redis successfully.');
});

redisClient.on('error', (err) => {
  console.error('Error connecting to Azure Redis:', err);
});

class JobQueue {
  static queues = {};

  static getQueue(name) {
    if (!JobQueue.queues[name]) {
      JobQueue.queues[name] = new Bull(name, {
        createClient: (type, _) => {
          switch (type) {
            case 'client':
              return redisClient;
            case 'bclient':
              return new Redis({
                ...redisConfig,
                maxRetriesPerRequest: null,
                enableReadyCheck: false,
              });
            case 'subscriber':
              if (!JobQueue.subscriberClient) {
                JobQueue.subscriberClient = new Redis({
                  ...redisConfig,
                  maxRetriesPerRequest: null,
                  enableReadyCheck: false,
                });
              }
              return JobQueue.subscriberClient;
            default:
              throw new Error('Unexpected connection type: ', type);
          }
        }
      });

      JobQueue.queues[name].on('completed', (job, result) => {
        console.log(`Job ${job.id} in queue ${name} completed with result: ${result}`);
      });

      JobQueue.queues[name].on('failed', async (job, err) => {
        console.log(err);
        console.error(`Job ${job.id} in queue ${name} failed with error: ${err.message}`);
        // Persist error in Redis
        await redisClient.lpush(
          `job_errors:${name}`,
          JSON.stringify({
            jobId: job.id,
            failedReason: job.failedReason,
            error: err.message,
            timestamp: new Date().toISOString(),
          }),
        );
      });
    }

    return JobQueue.queues[name];
  }

  static async addJob(queueName, data, options = {}) {
    try {
      const queue = JobQueue.getQueue(queueName);
      const job = await queue.add(data, {
        ...options,
        removeOnComplete: true,
        removeOnFail: false,
        attempts: 10,
      });

      return job.id;
    } catch (error) {
      throw new Error(`Error adding job to queue ${queueName}: ${error.message}`);
    }
  }

  static processJob(queueName, concurrency) {
    const queue = JobQueue.getQueue(queueName);
    switch (queueName) {
      case 'bouncedMessageQueue':
        queue.process(
          // queueName,
          concurrency,
          path.join(__dirname, 'queProcessor/bounceMessageProcessor.js'),
        );
        break;
      case 'newMessageQueue':
        queue.process(
          // queueName,
          concurrency,
          path.join(__dirname, 'queProcessor/newMessageProcessor.js'),
        );
        break;
      case 'webhookFailedQueue':
        queue.process(
          // queueName,
          concurrency,
          path.join(__dirname, 'queProcessor/webhookFailedProcessor.js'),
        );
        break;
      case 'autoReplyQueue':
        queue.process(
          // queueName,
          concurrency,
          path.join(__dirname, 'queProcessor/autoReplyProcessor.js'),
        );
        break;
    }
  }

  static async closeQueue(queueName) {
    if (JobQueue.queues[queueName]) {
      await JobQueue.queues[queueName].close();
    }
  }

  static async getFailedJobsCount(queueName) {
    try {
      const queue = JobQueue.getQueue(queueName);
      const failedCount = await queue.getFailedCount();
      return failedCount;
    } catch (error) {
      throw new Error(`Error retrieving failed jobs count for queue ${queueName}: ${error.message}`);
    }
  }
}

module.exports = JobQueue;
