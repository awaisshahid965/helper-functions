const axios = require('axios');
const moment = require('moment');
const mongoose = require('mongoose');
const CronofyService = require('./CronofyService.cjs');
const meetingLog = require('../models/meetingsLog');
const campaign = require('../models/campaign');
const leadModel = require('../models/lead');
const UserModel = require('../models/User');

const API_SERVICE_BACKEND_3 = "https://meeting.b2brocket.ai/api/v1/main";
const selfURL = 'https://meeting.b2brocket.ai/api/v1/main';
const CRONOFY_BASE_URL = "https://api.cronofy.com";

class UserMeetingSchedule {
    async getCalendarSlots(email, campaignId, all = false) {
        const user = await UserModel.findOne({ email }).select({ extra: 1 });
        const cronofyToken = user?.extra?.accessToken?.access_token;

        if(!cronofyToken) {
            return 'Calendar not connected!';
        }

        const calendarData = await this.fetchCalendar(cronofyToken);
        const calendarId = calendarData?.calendars[0]?.calendar_id;

        const slotPreset = await this.fetchSlotPreset(campaignId);
        const { slotDuration, buffer } = this.extractSlotData(slotPreset);

        const data = this.constructSlotRequestData(calendarData, calendarId, slotDuration, buffer);

        const availableSlots = await this.fetchAvailableSlots(cronofyToken, data);
        console.log(availableSlots)
        return all ? availableSlots : availableSlots.slice(0, 4);
    }

    async addMeetingScheduleByCronofy(meetingData) {
        let accessToken;
        const meetLog = new meetingLog();
        try {
            const userData = await this.getUserData(meetingData.email);
            if (!userData) {
                return this.handleMissingUser(meetLog);
            }

            const campaignData = await this.getCampaignData(meetingData.campaign_id);
            const user = this.prepareUserObject(campaignData, userData);
            accessToken = await this.getAccessToken(user, userData, meetingData.email, meetingData.campaign_id);

            if (!accessToken) {
                return this.handleUnauthorizedUser(meetLog);
            }

            const calendar = await CronofyService.getCalendars(accessToken);
            const selectedCalendar = CronofyService.prioritizeCalendars(calendar.calendars);


            return await this.scheduleMeeting(meetingData, user, selectedCalendar, accessToken, meetLog);
        } catch (error) {
            return this.handleMeetingError(error, meetLog);
        }
    }

    async fetchCalendar(cronofyToken) {
        const response = await axios.get(`${API_SERVICE_BACKEND_3}/calendar`, {
            headers: { cronofyToken },
        });
        return response.data;
    }

    async fetchSlotPreset(campaignId) {
        const response = await axios.get(`${API_SERVICE_BACKEND_3}/get-campaign-slot-preset/${campaignId}`, {
            headers: { "Content-Type": "application/json" },
        });
        return response.data;
    }

    extractSlotData(duration) {
        return {
            slotDuration: duration?.data?.slotsPreset || 60,
            buffer: duration?.data?.buffer,
        };
    }

    constructSlotRequestData(calendarData, calendarId, slotDuration, buffer) {
        let data = {
            participants: [
                {
                    members: [
                        {
                            sub: calendarData?.sub,
                            calendar_ids: [calendarId],
                            managed_availability: true,
                        },
                    ],
                    required: 1,
                },
            ],
            required_duration: { minutes: slotDuration },
            response_format: "slots",
            query_periods: [
                {
                    start: moment().utc().format("YYYY-MM-DDTHH:mm:ss[Z]"),
                    end: moment().add(6, "days").endOf("day").utc().format("YYYY-MM-DDTHH:mm:ss[Z]"),
                },
            ],
        };

        if (buffer && buffer.isSetBuffer) {
            data.buffer = {
                before: { minutes: Number(buffer.before) },
                after: { minutes: Number(buffer.after) },
            };
        }
        return data;
    }

    async fetchAvailableSlots(cronofyToken, data) {
        const response = await axios.post(`${API_SERVICE_BACKEND_3}/availability`, data, {
            headers: {
                "Content-Type": "application/json",
                cronofyToken,
            },
        });
        return response.data.data?.available_slots.map(slot => moment(slot.start).format("ddd, MMM Do h:mm A").toUpperCase());
    }

    async getUserData(email) {
        return await UserModel.findOne({ email });
    }

    async getCampaignData(campaignId) {
        return await campaign.findById(campaignId);
    }

    prepareUserObject(campaignData, userData) {
        if (Object.keys(campaignData).length === 0) {
            return userData;
        } else {
            return { ...campaignData, extra: userData?.extra };
        }
    }

    async getAccessToken(user, userData, email, campaignId) {
        const accessTokenObj = user.extra?.accessToken;
        if (accessTokenObj) {
            const tokenExpiresAt = accessTokenObj.expires_in + accessTokenObj.generatedAt;
            if (tokenExpiresAt <= Date.now()) {
                const newToken = await this.refreshAccessToken(user);
                await this.updateAccessToken(newToken, userData, email, campaignId);
                return newToken.access_token.access_token;
            } else {
                return accessTokenObj.access_token;
            }
        }
        return null;
    }

    async refreshAccessToken(user) {
        return await CronofyService.generateAccessToken(user);
    }

    async updateAccessToken(newToken, userData, email, campaignId) {
        const updateQuery = { 'extra.accessToken': { ...userData.extra.accessToken, generatedAt: Date.now(), ...newToken.access_token } };
        if (Object.keys(userData).length === 0) {
            await UserModel.updateOne({ email }, { $set: updateQuery });
        } else {
            await campaign.findByIdAndUpdate(campaignId, { $set: updateQuery });
        }
    }

    async scheduleMeeting(meetingData, user, selectedCalendar, accessToken, meetLog) {
        const eventDetails = this.constructEventDetails(meetingData, user, selectedCalendar, accessToken);
        const response = await axios.post(`${CRONOFY_BASE_URL}/v1/calendars/${selectedCalendar.calendar_id}/events`, eventDetails, {
            headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
        });

        if (!response.status === 200) {
            meetLog.save();
            return 'Failed to add meeting';
        }

        const leadData = await this.updateLeadData(meetingData.campaign_id, meetingData.email);
        return this.finalizeMeetingLog(meetLog, eventDetails, leadData);
    }

    constructEventDetails(meetingData, user, selectedCalendar, accessToken) {
        const { summary, description, time, location, attendees, lead_email } = meetingData;
        const start = time;
        const end = this.calculateEndTime(time, user?.slotsPreset || 60);
        const event_id = `${meetingData.campaign_id}/${lead_email}`;
        attendees.invite.push(this.constructMeetingConfirmationEmail(selectedCalendar.profile_name));

        return {
            event_id,
            summary,
            description,
            start,
            end,
            location,
            attendees,
            campaign_id: meetingData.campaign_id,
            conferencing: { profile_id: 'default' },
            tags: { private: [{ value: 'Internal planning' }, { value: 'Marketing' }] },
            subscriptions: [
                {
                    type: 'webhook',
                    uri: `${selfURL}/conferencing-notification`,
                    interactions: [{ type: 'conferencing_assigned' }, { type: 'conferencing_failing' }],
                },
            ],
        };
    }

    calculateEndTime(start, duration) {
        return moment(start).add(duration, 'minutes').toISOString();
    }

    constructMeetingConfirmationEmail(profileName) {
        const parts = profileName.split('@');
        return { email: `${parts[0]}+meeting@${parts[1]}` };
    }

    async updateLeadData(campaignId, email) {
        return await leadModel.findOneAndUpdate(
            { campaignIds: { $in: [mongoose.Types.ObjectId(campaignId)] }, email },
            { $push: { meetingBookedAt: Date.now() } }
        );
    }

    finalizeMeetingLog(meetLog, eventDetails, leadData) {
        meetLog.cronofy.leadsData = leadData;
        meetLog.cronofy.response = {
            success: true,
            msg: 'Meeting added successfully',
            data: { event_id: eventDetails.event_id, calendarEmail: eventDetails.attendees.invite[0].email },
        };
        meetLog.save();
        return 'Meeting added successfully';
    }

    handleMissingUser(meetLog) {
        meetLog.save();
        return 'User not found';
    }

    handleUnauthorizedUser(meetLog) {
        meetLog.cronofy.response = { msg: 'Calendar not connected!' };
        meetLog.save();
        return 'Calendar not connected!';
    }

    handleMeetingError(error, meetLog) {
        console.error('Error during meeting scheduling:', error);
        meetLog.cronofy.error = { success: false, msg: error.message, error };
        meetLog.save();
        return 'Error during meeting scheduling';
    }
}

module.exports = new UserMeetingSchedule()
