const { EmailStatusCategories } = require("../constants/EmailStatus");
const GptChatClient = require("./GptChatClient");
const EmailReplyParser = require("email-reply-parser")

const generateMailStatusPrompt = (email) => `
-- Prompt Objective --
Translate the prospect's email response to English if it's in another language. Then, assign one of the following statuses based on their explanation:
1. Interested: The person shows engagement by seeking more details, asking questions, or suggesting further discussion about a new business opportunity, counteroffer, or collaboration.
2. Not Interested: The response indicates no need for the product or service.
3. Unsubscribed: The email requests to stop communication or expresses a strong desire to cease all messages.
4. Wrong Person: The person is deceased, no longer employed, or not responsible for these inquiries.
5. Meeting Booked: The email includes plans for scheduling a future meeting or a scheduling tool link.
6. Out of Office: The email is an automated response indicating unavailability due to vacation or holiday.
7. Other: For system-generated messages and delivery failures.
-- Prompt Output --
Provide only the status corresponding to the prospect's email response.
Email: ${email}
`;

const caseInsensitiveCompare = (value, comparedValue) => value.toLowerCase().includes(comparedValue.toLowerCase())
const parseEmailContent = (email) => {
  var parsedEmail =  new EmailReplyParser().read(email ?? '');
  return parsedEmail.getVisibleText();
}

class EmailStatusEvaluator {
  constructor() {}

  _createEvaluationPrompts(email = '') {
    return [
      {
        role: "system",
        content: generateMailStatusPrompt(email)
      }
    ];
  }

  _getStatusFromGPTResponse(gptResponse) {
    const gptStatus = `${gptResponse?.choices?.[0]?.message?.content?.toLowerCase()?.trim() ?? ''}`
    if(caseInsensitiveCompare(gptStatus, EmailStatusCategories.NOT_INTERESTED)) {
      return EmailStatusCategories.NOT_INTERESTED
    } else if(caseInsensitiveCompare(gptStatus, EmailStatusCategories.INTERESTED)) {
      return EmailStatusCategories.INTERESTED
    } else if(caseInsensitiveCompare(gptStatus, EmailStatusCategories.MEETING_BOOKED)) {
      return EmailStatusCategories.MEETING_BOOKED
    } else if(caseInsensitiveCompare(gptStatus, EmailStatusCategories.OUT_OF_OFFICE)) {
      return EmailStatusCategories.OUT_OF_OFFICE
    } else if(caseInsensitiveCompare(gptStatus, EmailStatusCategories.WRONG_PERSON)) {
      return EmailStatusCategories.WRONG_PERSON
    } else if(caseInsensitiveCompare(gptStatus, EmailStatusCategories.UNSUBSCRIBED)) {
      return EmailStatusCategories.UNSUBSCRIBED
    }
    return EmailStatusCategories.OTHER
  }

  getAllStatuses() {
    return Object.values(EmailStatusCategories)
  }

  getDefaultStatus() {
    return EmailStatusCategories.OTHER
  }

  _checkInvalidEmail = (messageBody) => {
    const invalidMailRegex = new RegExp("\\b(failed|error|invalid|not found|rejected|failure|unable to send|undeliverable|authentication failed|bounced|blocked|expired|not delivered)\\b", 'i');
    return invalidMailRegex.test(messageBody)
  }

  _checkOutOfOffice(messageBody) {
    const outOfOfficeRegex = new RegExp("\\b(out of the office|out of office)\\b", 'i')
    return outOfOfficeRegex.test(messageBody)
  }

  async evaluateEmailReply(emailBody) {
    try {
      const parsedEmail = parseEmailContent(emailBody)

      if(this._checkInvalidEmail(parsedEmail)) {
        return EmailStatusCategories.OTHER
      }

      if(this._checkOutOfOffice(parsedEmail)) {
        return EmailStatusCategories.OUT_OF_OFFICE
      }

      const statusResponseFromGpt = await GptChatClient.sendPromptsToGpt(
        this._createEvaluationPrompts(parsedEmail)
      )
      
      return this._getStatusFromGPTResponse(statusResponseFromGpt)
    } catch(error) {
      console.log(`Error While evaluating email status...\n${error?.message ?? ''}`)
      return "not_processed"
    }
  }
}

module.exports = new EmailStatusEvaluator();
