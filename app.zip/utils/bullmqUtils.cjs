const { Queue, Worker, QueueScheduler } = require('bullmq');
const getRedisClient = require('../config/redis.cjs');

const queues = {}; // Cache for queues
const workers = {}; // Cache for workers
const queueSchedulers = {}; // Cache for queueSchedulers

function getQueue(queueName) {
    if (!queues[queueName]) {
        const redisClient = getRedisClient();
        queues[queueName] = new Queue(queueName, {
            connection: redisClient,
        });
    }
    return queues[queueName];
}

async function addToQueue(queueName, jobData) {
    const queue = getQueue(queueName);
    await queue.add('job', jobData);
}

function processQueue(queueName, processor) {
    const redisClient = getRedisClient();
    console.log(queueName, processor)
    const worker = new Worker(queueName, processor, {
        connection: redisClient,
        concurrency: 1,
    });

    worker.on('completed', (job) => {
        console.log(`Job completed: ${job.id}\n-\n`);
    });

    worker.on('failed', (job, err) => {
        console.error(`Job failed: ${job.id}`, err);
    });

    workers[queueName] = worker;

    // Create a QueueScheduler for delayed or failed jobs
    // if (!queueSchedulers[queueName]) {
    //     queueSchedulers[queueName] = new QueueScheduler(queueName, {
    //         connection: redisClient,
    //     });
    // }

    return worker;
}

async function closeAllQueues() {
    try {
        // Close all workers
        for (const [queueName, worker] of Object.entries(workers)) {
            worker.off('completed');
            worker.off('failed');

            await worker.close();
            console.log(`Worker for queue ${queueName} closed.`);
        }

        // Clear workers cache
        workers = {};

        // Close all queues and schedulers
        for (const [queueName, queue] of Object.entries(queues)) {
            // Check if there are any remaining workers using the queue
            const isQueueInUse = Object.values(workers).some(worker => worker.queue.name === queueName);

            if (!isQueueInUse) {
                delete queues[queueName];
                console.log(`Queue ${queueName} removed from cache.`);
            }
        }

        for (const [queueName, scheduler] of Object.entries(queueSchedulers)) {
            await scheduler.close();
            console.log(`QueueScheduler for queue ${queueName} closed.`);
        }

        // Clear queueSchedulers cache
        queueSchedulers = {};

    } catch (error) {
        console.error('Error closing all queues and workers:', error);
    }
}

module.exports = {
    getQueue,
    addToQueue,
    processQueue,
    closeAllQueues,
};
