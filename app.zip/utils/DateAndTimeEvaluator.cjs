const GptChatClient = require("./GptChatClient");

const generateDateAndTimePromot = emailBody => `
    You need to extract the date and time from a user message and convert it into a human-readable format. The format should be as follows:
  
    Date: DD Month
    Time: HH:MM AM/PM
    
    Guidelines:
    
    1. **Message Parsing:**
    
       The user’s message may include:
       - Date and time references such as "today", "tomorrow", "next week", or specific times like "11 o'clock".
       - Explicit date and time formats such as "2023-07-01 23:59:59".
       Accurately identify the date and time from the user’s message.
   
    2. **Date and Time Interpretation:**
    
       - **"Today"** should be replaced with the current date.
       - **"Tomorrow"** should be replaced with the date for the next day.
       - **"Next week"** should be replaced with the same day next week.
       - Specific time mentions (like "11 o'clock") should be converted to that hour of the specified day.
       - Explicit date formats (e.g., "2023-07-01 23:59:59") should be parsed directly, and only the date and time should be extracted.
   
    3. **Date and Time Conversion:**
    
       Convert the extracted date and time into the following format:
       - **Date:** DD Month (e.g., 13 August)
       - **Time:** HH:MM AM/PM (e.g., 12:00 AM for midnight)
    
    **Examples:**
    
    1. **Input:** "Today 11 o'clock"
       **Output:**
       - **Date:** 07 August (Assuming today’s date is August 7)
       - **Time:** 11:00 AM
    
    2. **Input:** "Tomorrow at 3 PM"
       **Output:**
       - **Date:** 08 August (Assuming tomorrow’s date is August 8)
       - **Time:** 03:00 PM
    
    3. **Input:** "2023-07-01 23:59:59"
       **Output:**
       - **Date:** 01 July
       - **Time:** 11:59 PM
    
    **Additional Notes:**
    
       - Ensure accurate conversion from 24-hour format to 12-hour format with AM/PM.
       - If the message includes relative time phrases, calculate the exact date and time accordingly.
       - If the message includes explicit date formats, parse the date and time directly from the format provided.
  
    User Message:
    ${emailBody}
    `;

function extractDateTimeToISOString(text) {
    console.log(text, "texttexttext");

    // Regular expressions to match various date and time formats
    const dateRegex = /(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(?:\s+(\d{4}))?/i;
    const timeRegex = /(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?/i;

    // Find date and time in the text
    const dateMatch = text.match(dateRegex);
    const timeMatch = text.match(timeRegex);
    if (!dateMatch || !timeMatch) {
        throw new Error("Couldn't find a valid date and time in the given text.");
    }

    // Parse date
    const day = dateMatch[1].padStart(2, '0');
    const month = dateMatch[2];
    const year = dateMatch[3] || new Date().getFullYear(); // Use current year if not provided

    // Parse time
    let hours = parseInt(timeMatch[1]);
    const minutes = timeMatch[2];
    const seconds = timeMatch[3] || '00';
    const ampm = timeMatch[4] ? timeMatch[4].toLowerCase() : null;

    // Adjust hours for PM
    if (ampm === 'pm' && hours < 12) hours += 12;
    if (ampm === 'am' && hours === 12) hours = 0;

    // Pad hours with leading zero if necessary
    hours = hours.toString().padStart(2, '0');

    // Create a Date object
    const monthIndex = new Date(`${month} 1, 2000`).getMonth();
    const date = new Date(year, monthIndex, day, hours, minutes, seconds);

    // Return the ISO string
    return date.toISOString();
}

class DateAndTimeEvaluator {

    _createEvaluationPrompts(emailBody) {
        return [
            {
                role: 'system',
                content: generateDateAndTimePromot(emailBody)
            },
        ]
    }

    _getPromptOptions() {
        return {
            stop: [" user:", " assistant:"],
            top_p: 0.95,
            temperature: 0.7,
        }
    }

    _extractDataFromResponse(responseData) {
        const gptRawResponse = responseData?.choices?.[0]?.message?.content;
        return extractDateTimeToISOString(gptRawResponse);
    }

    async evaluateDateAndTimeFromEmail(emailBody) {
        const responseData = await GptChatClient.sendPromptsToGpt(
            this._createEvaluationPrompts(emailBody),
            this._getPromptOptions()
        )

        return this._extractDataFromResponse(responseData)
    }
}

module.exports = new DateAndTimeEvaluator()
