const axios = require('axios');
const { mailBoxes } = require("../config/config");

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function getAccessTokenFromRefreshToken(refreshToken) {
    const values = {
        client_id: mailBoxes.googleWebAppConfig.client_id,
        client_secret: mailBoxes.googleWebAppConfig.client_secret,
        refresh_token: refreshToken,
        grant_type: 'refresh_token',
    };

    const tokenResponse = await axios.post(
        mailBoxes.googleWebAppConfig.token_url,
        new URLSearchParams(values).toString(),
        {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        },
    );

    return tokenResponse;
}

const getLatestAccessToken = async (refreshToken) => {
    const tokenResponse = await getAccessTokenFromRefreshToken(refreshToken);
    return tokenResponse.data.access_token;
};

function createEmail(createEmailParams) {
    const emailLines = [];
    const { to, subject, message, cc, bcc, messageId } = createEmailParams;

    cc && emailLines.push(`Cc: ${cc}`);
    bcc && emailLines.push(`Bcc: ${bcc}`);

    emailLines.push(`To: ${to}`);
    emailLines.push('MIME-Version: 1.0');
    emailLines.push(`Subject: ${subject}`);

    messageId && emailLines.push(`In-Reply-To: ${messageId}`);

    emailLines.push('Content-Type: text/html; charset="UTF-8"');
    emailLines.push('');
    emailLines.push(message);

    return emailLines.join('\r\n').trim();
}

async function sendEmail({ refreshToken, accessToken, to, subject, message, threadId, cc = [], bcc = [], messageId = null, delayInMs = 0 }) {
    const url = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send';
    const email = createEmail({ to, subject, message, cc, bcc, messageId });
    const encodedEmail = Buffer.from(email).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    let newAccessToken = accessToken;

    try {
        if(!newAccessToken) {
            newAccessToken = await getLatestAccessToken(refreshToken);
        }

        await delay(delayInMs);
        const response = await axios.post(
            url,
            { raw: encodedEmail, threadId },
            {
                headers: {
                    Authorization: `Bearer ${newAccessToken}`,
                    'Content-Type': 'application/json',
                },
            },
        );
        console.log(response.data, 'mail sent successfully');
        return response.data;
    } catch (error) {
        console.error('Error sending email:', error.message);
        throw new Error('Failed to send email');
    }
}

async function sendMultipleEmails(emails) {
    try {
        const accessToken = await getLatestAccessToken(refreshToken);

        for(let data of emails) {
            await sendEmail({
                ...data,
                accessToken
            })
        }

    } catch(error) {
        throw new Error('Error Sending multiple Emails', error.message)
    }
}

async function getMessageDataForRfcId(messageId, accessToken) {
    if (!messageId) {
        throw new Error('Invalid message id!');
    }

    const url = `https://gmail.googleapis.com/gmail/v1/users/me/messages?q=rfc822msgid:${encodeURIComponent(messageId)}`;
    const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
    });

    return response.data.messages[0];
}

const getThreadIdFromMessageId = async (messageId, refreshToken) => {
    const accessToken = await getLatestAccessToken(refreshToken);
    let fetchedMessageData = await getMessageDataForRfcId(messageId, accessToken);

    return fetchedMessageData;
};

module.exports = {
    sendEmail,
    sendMultipleEmails,
    getThreadIdFromMessageId,
}
