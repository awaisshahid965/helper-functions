const { default: GptChatClient } = require("./GptChatClient");
const { default: UserMeetingSchedule } = require("./UserMeetingSchedule.cjs");

class AutoReplyPromptGenerator {
    constructor(gptChatClient, calendarSlotFetcher) {
        this.gptChatClient = gptChatClient;
        this.calendarSlotFetcher = calendarSlotFetcher;
    }

    async generatePrompt({ senderName, senderTitle, companyName, productDesc, campaignDesc, testimonials, emailStructure, body, companyWebsite, calendarSlots }) {
        const slotsString = calendarSlots.length > 0
            ? `<b>Available Meeting Slots: ${calendarSlots.join(', ')}</b>`
            : '';

        return `
        Read the PROSPECT EMAIL THREAD below and then you will continue the conversation and reply as if you are me using MY INFORMATION. The objective should be to be helpful but ultimately drive the prospect toward the CALL TO ACTION. If the last email was from me, meaning the prospect did not reply, tailor the message accordingly and try a different approach to get the prospect to do the CALL TO ACTION.
        
        USER INFORMATION
        Full Name: ${senderName}
        Title: ${senderTitle}
        Company: ${companyName}
        Company Description: ${campaignDesc}
        Service/Product Description: ${productDesc}
        Success Stories: ${testimonials}
        
        EMAIL STRUCTURE
        Creativeness: ${emailStructure?.creativeness}
        Length: ${emailStructure?.length}
        Tone: ${emailStructure?.tone}
        
        CALL TO ACTION
        ${companyWebsite}
        
        ${slotsString}
        
        PROSPECT EMAIL THREAD
        ${body}
        
        PLEASE MAKE SURE EMAIL RESPONSE HAS ONLY 60-70 WORDS
        
        IMPORTANT: If appropriate, include one or more of the available meeting slots in your response. If no slots are available or if it's not appropriate to include them, you may omit them from your response.
      `;
    }

    async generateAutoReply({ status, campaignData, initialEmail }) {
        if (["Interested", "Out Of Office", "Meeting Booked"].includes(status)) {
            const calendarSlots = status === "Meeting Booked"
                ? await UserMeetingSchedule.getCalendarSlots(campaignData.clientEmail, campaignData.campaignId)
                : [];

            const prompt = await this.generatePrompt({
                senderName: campaignData.senderName,
                senderTitle: campaignData.senderTitle,
                companyName: campaignData.companyName,
                productDesc: campaignData.productDesc,
                campaignDesc: campaignData.campaignDesc,
                testimonials: campaignData.testimonials,
                emailStructure: campaignData.emailStructure,
                body: initialEmail.body,
                companyWebsite: campaignData.companyWebsite,
                calendarSlots,
            });

            const gptResponse = await GptChatClient.sendPromptsToGpt([{ role: 'system', content: prompt }]);
            return gptResponse?.choices?.[0]?.message?.content;
        }
        return null;
    }
}

module.exports = new AutoReplyPromptGenerator();
