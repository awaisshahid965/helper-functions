const axios = require('axios');
const { API_ADMIN_SERVICE_BACKEND } = require('../config/config');

const sendEmailNotification = async ({ email, subject, content }) => {
    try {
        await axios.post(`${API_ADMIN_SERVICE_BACKEND}/queue-email-notification`, {
            email: [email],
            subject,
            content,
        });
    } catch(error) {
        throw error;
    }
}

module.exports = {
    sendEmailNotification,
}
