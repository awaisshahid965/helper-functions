const axios = require('axios');

class CronofyService {
    constructor() {
        const {
            CRONOFY_CLIENT_ID = "Nbe1BSQG8V83lYQQDY4e8zGX8vpEXdrG",
            CRONOFY_CLIENT_SECRET = "CRN_B5d4Xvpv6IaNw6UDIKVgD8wTdYfFBiUe0BUz7m",
            CRONOFY_BASE_URL = "https://api.cronofy.com"
        } = process.env;
        this.clientId = CRONOFY_CLIENT_ID;
        this.clientSecret = CRONOFY_CLIENT_SECRET;
        this.baseUrl = CRONOFY_BASE_URL;
        this.httpClient = axios.create({
            baseURL: this.baseUrl,
            headers: { 'Content-Type': 'application/json' },
        });
    }

    async generateAccessToken(user) {
        const url = '/oauth/token';
        const body = {
            client_id: this.clientId,
            client_secret: this.clientSecret,
            grant_type: 'refresh_token',
            refresh_token: user.extra.accessToken.refresh_token,
        };

        try {
            const { data } = await this.httpClient.post(url, body);
            return { access_token: data };
        } catch (error) {
            this.handleError(error, 'Failed to obtain access token');
        }
    }

    async getCalendars(accessToken) {
        const url = '/v1/calendars';
        const headers = { Authorization: `Bearer ${accessToken}` };

        try {
            const { data } = await this.httpClient.get(url, { headers });
            return data;
        } catch (error) {
            this.handleError(error, 'Failed to fetch calendars');
        }
    }

    prioritizeCalendars(calendars) {
        return calendars.find(calendar => calendar.provider_name === 'google') || 
               calendars.find(calendar => calendar.provider_name === 'apple') || 
               calendars.find(calendar => calendar.provider_name === 'outlook') || 
               calendars[0] || null;
    }

    async getConnectedAccounts() {
        const url = '/account/connect_profiles';
        try {
            const accessToken = await this.getOAuthToken();
            const headers = { Authorization: `Bearer ${accessToken}` };
            const { data } = await this.httpClient.get(url, { headers });
            return data;
        } catch (error) {
            this.handleError(error, 'Failed to fetch connected accounts');
        }
    }

    async getOAuthToken() {
        const url = '/oauth/token';
        const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
        const body = new URLSearchParams({
            client_id: this.clientId,
            client_secret: this.clientSecret,
            grant_type: 'client_credentials',
        });

        try {
            const { data } = await this.httpClient.post(url, body.toString(), { headers });
            return data.access_token;
        } catch (error) {
            this.handleError(error, 'Failed to obtain OAuth token');
        }
    }

    handleError(error, message) {
        console.error(`${message}:`, error.response ? error.response.data : error.message);
        throw new Error(`${message}. Please check the logs for details.`);
    }
}

module.exports = new CronofyService();
