const moment = require("moment");
const EmailReplyParser = require("email-reply-parser")

const _parseEmailContent = (email) => {
    var parsedEmail =  new EmailReplyParser().read(email ?? '');
    return parsedEmail.getVisibleText();
}  

function generateResponseBody({ isSlotAvailable, extractTime, senderName, subject, calendarSlotsResult = [] }) {
    if (isSlotAvailable) {
        const formattedDate = moment(extractTime).format('YYYY-MM-DD');
        const formattedTime = moment(extractTime).format('HH:mm');

        return `
            <p>Dear User,</p>
            <p>I hope this email finds you well. I am writing to confirm that your meeting has been successfully booked.</p>
            <p><strong>Details of the Meeting:</strong></p>
            <p>Date: ${formattedDate}<br>
            Time: ${formattedTime}</p>
            <p>If you have any questions or need further assistance, please feel free to reach out. We look forward to meeting with you and discussing <strong>${subject}</strong>.</p>
            <p>Thank you for choosing our services. We are committed to ensuring that your experience is seamless and satisfactory.</p>
            <p>Best regards,<br>
            ${senderName}</p>
        `;
    } else {
        const availableSlots = calendarSlotsResult.slice(0, 4).map(slot => `<li>${slot}</li>`).join('');

        return `
            <p>Dear User,<br><br>
            Unfortunately, the selected slot is no longer available. Please choose another slot from the options provided below.</p>
            <h3>Slots Available For Meeting</h3>
            <ul>${availableSlots}</ul>
            <p>If you have any questions or need further assistance, please feel free to reach out. We look forward to meeting with you and discussing <strong>${subject}</strong>.</p>
            <p>Thank you for choosing our services. We are committed to ensuring that your experience is seamless and satisfactory.</p>
            <p>Best regards,<br>
            ${senderName}</p>
        `;
    }
}

function parseDateTimeToISOString(text) {
    // Regular expressions to match various date and time formats
    const datePattern = /(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(?:\s+(\d{4}))?/i;
    const timePattern = /(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?/i;

    // Extract date and time from text
    const dateMatch = text.match(datePattern);
    const timeMatch = text.match(timePattern);
    
    if (!dateMatch || !timeMatch) {
        throw new Error("Unable to locate a valid date and time in the provided text.");
    }

    // Parse the extracted date components
    const day = dateMatch[1].padStart(2, '0');
    const monthName = dateMatch[2];
    const year = dateMatch[3] || new Date().getFullYear();

    // Parse the extracted time components
    let hours = parseInt(timeMatch[1]);
    const minutes = timeMatch[2];
    const seconds = timeMatch[3] || '00';
    const period = timeMatch[4] ? timeMatch[4].toLowerCase() : null;

    // Adjust hours for 12-hour format (AM/PM)
    if (period === 'pm' && hours < 12) hours += 12;
    if (period === 'am' && hours === 12) hours = 0;
    hours = hours.toString().padStart(2, '0');

    const monthIndex = new Date(`${monthName} 1, 2000`).getMonth();
    const dateObject = new Date(year, monthIndex, day, hours, minutes, seconds);

    return dateObject.toISOString();
}

function checkIsSlotAvailable(data, isoString) {
    const meetingTime = moment(isoString).format("ddd, MMM Do h:mm A").toUpperCase()

    return data.includes(meetingTime);
}

function addDurationToIsoString(isoString, duration) {
    const date = new Date(isoString);
    date.setMinutes(date.getMinutes() + duration);

    return date.toISOString();
}

function generateEmailHTML(emailBody) {
    const formattedBody = emailBody
        ?.split('\n')
        .map((line) => {
            if (line.startsWith('>')) {
                return line.substring(1);
            } else {
                return line;
            }
        })
        .join('<br />');

    const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Email</title>
    </head>
    <body>
      ${formattedBody}
    </body>
    </html>`;

    return html;
}

function generateConversationFromLeadResponses(data) {
    let content;

    if(!data?.conversations?.length) {
        content = data?.body;
    } else {
        content = data.conversations.map(c => {
            const fromText = c.from ? `From: &lt;${c.from}&gt;\n` : '';
            const sentAt = c.date ? `Sent At: ${new Date(c.date).toLocaleTimeString()}\n` : '';
            const subject = c.subject ? `Subject: ${c.subject}\n` : '';
            return `
                <pre>${fromText}${sentAt}${subject}\n</pre>
                ${_parseEmailContent(c.body)}
            `;
        })
        .reverse()
        .join('<br /><div style="border-top: 1px solid lightgray; margin: 10px 0;"></div>');
    }

    return content;
}

module.exports = {
    generateResponseBody,
    parseDateTimeToISOString,
    addDurationToIsoString, // endTimeIsoString
    checkIsSlotAvailable,
    generateEmailHTML,
    generateConversationFromLeadResponses,
}
