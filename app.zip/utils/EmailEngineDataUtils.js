class EmailEngineDataUtils {

    static _extractNewMessageData = (payload) => {
        const { messageId, date, text, sender, inReplyTo, to, subject, isBounce = false, cc } = payload.data;
        const repliedMessageId = typeof inReplyTo === 'string' ? inReplyTo : inReplyTo?.[0];
        const ccList = (cc ?? []).map(data => data?.address ?? '');
        const forwardedTo = (to ?? []).slice(1).map(data => data?.address ?? '');
      
        return {
          messageId: repliedMessageId ?? messageId,
          currentMessageId: messageId,
          senderEmail: to?.length > 0 ? to?.[0]?.address : '',
          messageEmail: sender?.address?.toLowerCase(),
          date,
          body: text?.plain,
          subject,
          plainBody: text?.plain,
          isBounce: isBounce,
          ccList,
          forwardedTo,
        };
    }

    static _extractBouncedMessageData = (payload) => {
        const { to = '', subject = '' } = payload?.data?.messageHeaders;
        const repliedMessageId = payload?.data?.messageHeaders?.['in-reply-to']?.[0];
        const messageId = payload?.data?.messageHeaders?.['message-id']?.[0];
    
        return {
          messageId: repliedMessageId ?? messageId,
          currentMessageId: messageId,
          senderEmail: payload.account,
          messageEmail: to?.[0],
          date: payload.date,
          body: JSON.stringify(payload.data.response),
          subject: subject?.[0],
          plainBody: '',
        };
    }

    static extractEmailEventData(responsePayload) {
        const extractorFunction = {
            'messageNew': this._extractNewMessageData,
            'messageBounce': this._extractBouncedMessageData,
        }

        if(!extractorFunction[responsePayload.event]) {
            return null
        }
        return extractorFunction[responsePayload.event](responsePayload)
    }
}

module.exports = EmailEngineDataUtils
