const { newMessage } = require('../../controllers/campagins');
const mongoose = require('mongoose');
require('colors');
// DB Connection work
const { MongoURI } = require('../../config/keys');
// Connect MongoDB

module.exports = async (job, done) => {
  await mongoose
    .connect(MongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useFindAndModify: false,
      serverSelectionTimeoutMS: 50000,
      socketTimeoutMS: 50000,
    })
    .then(() => {
      console.log('MongoDB Connected'.green.bold);
      // const clearPollInt = startPolling();
    })
    .catch((err) => console.log(err));

  await newMessage(job.data);
  await mongoose.disconnect();
  done();
};
