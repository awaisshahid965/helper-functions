const mongoose = require('mongoose');
const moment = require('moment');
const userAnalytics = require('../models/userAnalyticsCache');
const User_registered = require('../models/User');
const campaign = require('../models/campaign');
module.exports = class AnalyticsUpdater {
  constructor() {}

  isDateSame(date1, date2) {
    const momentDate1 = moment(date1).startOf('day');
    const momentDate2 = moment(date2).startOf('day');

    return momentDate1.isSame(momentDate2);
  }
  async findUserById(userId) {
    return await User_registered.findOne({
      _id: mongoose.Types.ObjectId(userId),
    });
  }
  async createNewUserForAnalytics(userId) {
    return await userAnalytics.create({
      user: userId,
    });
  }
  async findLatestUserAnalyticsByCreatedAt(userId) {
    const analyticLatest = await userAnalytics.find({ user: userId }).sort({ dateAdded: -1 }).limit(1);

    return analyticLatest.find((data) => data);
  }
  async createNewAnalyticIfCreatedAtIsDifferent(userId) {
    const latestUserAnalytics = await this.findLatestUserAnalyticsByCreatedAt(userId);
    if (!latestUserAnalytics) {
      return await this.createNewUserForAnalytics(userId);
    }
      if (!this.isDateSame(latestUserAnalytics.dateAdded, moment().format())) {
      return await this.createNewUserForAnalytics(userId);
    } else {
      return latestUserAnalytics;
    }
  }
  async findUserbyCampaignId(campaignId) {
    const foundCampaign = await campaign.findById(campaignId);
    if (!foundCampaign) {
      return null;
    }

    const user = await User_registered.findOne({ email: foundCampaign.clientEmail });
    if (!user) {
      return null;
    }
    return user;
  }
  async updateAnalytics(key, value, campaignId) {
    //operation can be either increment or decrement
    const user = await this.findUserbyCampaignId(campaignId);

    if (!user) {
      return;
    }
    const analayticalTables = await this.createNewAnalyticIfCreatedAtIsDifferent(user._id);
    await userAnalytics.findOneAndUpdate(
      { user: user._id, dateAdded: analayticalTables.dateAdded },
      { $inc: { [key]: value } },
    );
  }
};
