// packages
require('colors');
const mongoose = require('mongoose');
const { default: axios } = require('axios');
const EmailReplyParser = require("email-reply-parser");

// utils
const EmailEngineDataUtils = require('../utils/EmailEngineDataUtils');
const AnalyticsUpdater = require('./analyticUpdate');
const EmailStatusEvaluator = require('../utils/EmailStatusEvaluator');
const JobQueue = require('../utils/JobQueue.cjs');

// constants & configs
const { EmailStatusCategories } = require('../constants/EmailStatus');
const { API_ADMIN_SERVICE_BACKEND } = require('../config/config');

// models
const Sent_Model = require('../models/sentEmails');
const mailboxesModel = require('../models/mailboxes');
const leadResponsesModel = require('../models/leadResponses');
const { AnalyticsCache } = require('../models/AnalyticsCache');
const leadModel = require('../models/lead');
const campaign = require('../models/campaign');
const LeadResponsesErrorModel = require('../models/LeadResponseErrors');
const blacklistModel = require('../models/blacklist');
const ExclusionListModel = require('../models/ExclusionList');

const analyticUpdate = new AnalyticsUpdater();

const positiveStatuses = [
  EmailStatusCategories.INTERESTED,
  EmailStatusCategories.MEETING_BOOKED,
  EmailStatusCategories.MEETING_COMPLETED,
  EmailStatusCategories.WON,
];

const sendNotificationForPositiveReply = async (email, subject, content, emailStatus, clientEmail) => {

  if(!email) {
    return null
  }

  if (!positiveStatuses.includes(emailStatus)) {
    return null;
  }

  try {
    await axios.post(`${API_ADMIN_SERVICE_BACKEND}/queue-interested-reply-notification`, {
      email: [email],
      subject,
      content,
      clientEmail,
    });
  } catch (error) {
    console.log('error while sending notification');
  }

  return null;
};

const excludePositiveReplyEmail = async (clientEmail, messageEmail, emailStatus) => {
  
  if(!positiveStatuses.includes(emailStatus)) {
    return null;
  }

  try {
    const ExclusionList = await ExclusionListModel.findOne({ clientEmail });
    
    if (ExclusionList) {
        ExclusionList.emails.push({
          value: messageEmail,
          fileName: "REPLIES_SERVICE_AUTO",
          createdAt: new Date().toISOString(),
        });
        await ExclusionList.save();

    } else {
      await ExclusionListModel.create({
        clientEmail,
        emails: [{
          value: messageEmail,
          fileName: "REPLIES_SERVICE_AUTO",
          createdAt: new Date().toISOString(),
        }],
      });
    }
  } catch(err) {
    console.error("Error add email to exclusion list\n", err)
  } finally {
    return null;
  }
}

const handleUninterestedReplies = async (email, emailStatus) => {

  const unInterestedReplies = [
    EmailStatusCategories.NOT_INTERESTED,
    EmailStatusCategories.WRONG_PERSON,
    EmailStatusCategories.UNSUBSCRIBED
  ];

  if(!unInterestedReplies.includes(emailStatus)) {
    return null;
  }

  try {
    const blacklist = await blacklistModel.findOne({ email });
    if (!blacklist) {
      await blacklistModel.create({
        email,
        admin: 'REPLIES_SERVICE_AUTO'
      });
    }
  } catch(err) {
    console.error("Error blacklisting uninterested reply\n", err)
  } finally {
    return null;
  }
}

const processPositiveReplyNotification = async (notificationEmail, messageEmail, emailStatus, clientEmail) => {

  if(!positiveStatuses.includes(emailStatus)) {
    return null;
  }

  try {
    await sendNotificationForPositiveReply(
      notificationEmail,
      `You have an ${emailStatus} reply from prospect`,
      `Hi, you have received a ${emailStatus} reply form ${messageEmail}, please visit b2brocket.ai dashboard for details.`,
      emailStatus,
      clientEmail
    );
  } catch(err) {
    console.error("Error sending positive reply notification\n", err)
  } finally {
    return null;
  }
}

function extractEmailReplyText(email) {
  const parsedEmail = new EmailReplyParser().read(email ?? '');
  return parsedEmail.getVisibleText();
}

async function createOrUpdateLeadResponseForGmailWatcher(
  campaignId,
  senderEmail,
  messageEmail,
  actualEmail,
  subject,
  body,
  messageId,
  leadId,
  date,
  plainBody,
  currentMessageId,
  isBounced,
  ccList,
  forwardedTo
) {
  try {
    const query = {
      messageId: messageId,
    };

    const conversationdata = {
      subject,
      messageId: currentMessageId,
      body,
      from: messageEmail,
      date,
      ccList,
      forwardedTo,
    };

    let status = "Bounced";
    if (!isBounced) {
      status = await EmailStatusEvaluator.evaluateEmailReply(body ?? '');
    }

    const update = {
      $setOnInsert: {
        leadId,
        campaignId,
        email: messageEmail,
        senderEmail: senderEmail,
        subject,
        body,
        conversations: [conversationdata],
        messageDate: date,
        messageId,
        status,
        createdAt: new Date().toISOString(),
        actualEmail,
      },
    };
    const options = { upsert: true, setDefaultsOnInsert: true };
    let result = await leadResponsesModel.findOne(query);
    if (result) {
      const conversation = {
        subject: result?.subject,
        messageId: currentMessageId,
        body: extractEmailReplyText(plainBody),
        from: messageEmail,
        date,
        ccList,
        forwardedTo,
      };
      result.conversations.push(conversation);
      result.status = status;
      result.save();
    } else {
      await leadResponsesModel.findOneAndUpdate(query, update, options);
    }
    return {
      ...result,
      isStatusInterested: status === EmailStatusCategories.INTERESTED,
      status,
    };
  } catch (err) {
    console.error('Error updating document in MongoDB', err);
    throw err;
  }
}

function formatToUTCStartOfDay(isoDateString) {
  const date = new Date(isoDateString);
  date.setUTCHours(0, 0, 0, 0);
  const formattedString = date.toISOString().replace('Z', '+00:00');
  return formattedString;
}

async function webhookFailed(data) {
  try {
    const leadResponseError = await LeadResponsesErrorModel({
      errorPayload: JSON.stringify(data ?? {}),
    });
    await leadResponseError.save();
  } catch (error) {
    console.log('error while saving webhook error', error);
  }
}

async function updateBouncedEmailAnalyticsStats(analyticsObj, emailSequence = '', emailStep = '') {
  const sequenceType = {
      'initial': 'initialSeqStats',
      'meetingBooked': 'meetingBookedSeqStats',
      'meetingMissed': 'meetingMissedSeqStats',
      'conversation': 'conversationSeqStats',
  }
  const sequence = sequenceType[emailSequence] ?? '';

  const incUpdatesForInitialSeqStats = {};
  const seqStepStat = analyticsObj.analytics[sequence] ?? {};

  if( seqStepStat[emailStep]?.emailDelivered === 'number') {
      incUpdatesForInitialSeqStats[`analytics.${sequence}.${emailStep}.emailDelivered`] = -1;
  }

  await AnalyticsCache.findByIdAndUpdate(analyticsObj._id, {
      $inc: {
          'analytics.emailDelivered': -1,
          ...incUpdatesForInitialSeqStats,
      }
  })
}

async function updateAnalytics(sentMailData, emailStatus) {
  if (!sentMailData.createdAt) {
    console.log('Invalid data in sentMailData provided in updateNewEmailAnalyticsStats');
    return;
  }

  const isEmailUnbscribed = emailStatus === EmailStatusCategories.UNSUBSCRIBED;
  const campaignId = mongoose.Types.ObjectId(sentMailData.campaignId);
  const currentDate = new Date();
  const formattedCurrentDate = formatToUTCStartOfDay(currentDate);
  const emailOpenedDate = sentMailData.opened?.[0] ? formatToUTCStartOfDay(sentMailData.opened[0]) : null;
  const emailClickedDate = sentMailData.clicked?.[0] ? formatToUTCStartOfDay(sentMailData.clicked[0]) : null;

  const bulkOps = [];

  if (isEmailUnbscribed) {
    bulkOps.push({
      updateOne: {
        filter: { campaignId, date: formattedCurrentDate },
        update: { $inc: { 'analytics.unSubscribeCount': 1 } },
        upsert: true,
        setDefaultsOnInsert: true
      }
    });
  }

  if (emailOpenedDate) {
    bulkOps.push({
      updateOne: {
        filter: { campaignId, date: emailOpenedDate },
        update: {
          $set: {
            'analytics.emailOpened': {
              $max: [{ $subtract: ['$analytics.emailOpened', 1] }, 0]
            },
          }
        }
      }
    });
  }

  if (emailClickedDate) {
    bulkOps.push({
      updateOne: {
        filter: { campaignId, date: emailClickedDate },
        update: {
          $set: {
            'analytics.emailClicked': {
              $max: [{ $subtract: ['$analytics.emailClicked', 1] }, 0]
            }
          }
        }
      }
    });
  }

  try {
    if (bulkOps.length > 0) {
      await AnalyticsCache.bulkWrite(bulkOps);
    }
  } catch (error) {
    console.error('Error updating analytics cache for new mail:', error);
  } finally {
    return null;
  }
}


const bouncedMessage = async (requestBody) => {
  try {
    const emailData = EmailEngineDataUtils.extractEmailEventData(requestBody);
    const { messageId = '', date, senderEmail, messageEmail, body, subject, plainBody, currentMessageId } = emailData ?? {};
  
    const sentMail = await Sent_Model.findOne({ messageId });
  
    if (!sentMail) {
      console.log(`no email found in sentmail for bouncedMessage: ${messageId}`)
      return;
    };

    const leadId = sentMail.leadId;
    const campaignId = sentMail.campaignId;
    const actualEmail = sentMail.to;

    const analyticsObj = await AnalyticsCache.findOne({
      campaignId: mongoose.Types.ObjectId(sentMail.campaignId),
      date: {
        $eq: formatToUTCStartOfDay(sentMail.createdAt),
      },
    });

    if (!analyticsObj) return;

    sentMail.isBounced = true;

    await Promise.all([
      createOrUpdateLeadResponseForGmailWatcher(
        campaignId,
        senderEmail,
        messageEmail,
        actualEmail,
        `Delivery Failure - ${sentMail.email?.subject}` ?? subject,
        body,
        messageId,
        leadId,
        date,
        plainBody,
        currentMessageId,
        true, // isBounced
        [], // ccList
        [] // forwardedTo
      ),
      updateBouncedEmailAnalyticsStats(
        analyticsObj,
        sentMail.sequence,
        sentMail.step
      ),
      sentMail.save()
    ]);
  } catch (err) {
    console.error('Error handling bounced message:', err);
  }
};

const checkInvalidMessageBody = (messageBody) => {
  const messageInvalidationCheckerRegex = new RegExp(
    '\\b(failed|error|invalid|not found|rejected|failure|unable to send|undeliverable|authentication failed|bounced|blocked|expired)\\b',
  );
  return messageInvalidationCheckerRegex.test(messageBody);
};

const newMessage = async (reqBody) => {
  try {
    const emailData = EmailEngineDataUtils.extractEmailEventData(reqBody);
    const {
      messageId,
      date,
      senderEmail,
      messageEmail,
      body,
      subject,
      plainBody,
      currentMessageId,
      isBounce,
      ccList,
      forwardedTo
    } = emailData;

    if (isBounce) {
      await bouncedMessage(reqBody);
      return;
    }

    const sentMail = await Sent_Model.findOne({ messageId });
    if (!sentMail) {
      await JobQueue.addJob('autoReplyQueue', {
        emailData,
        continues: true,
        campaignData: null,
        emailStatus: null,
      });
      return;
    }

    const leadId = sentMail.leadId || '';
    const campaignId = sentMail.campaignId || '';
    const actualEmail = sentMail.to;

    if (campaignId && leadId) {
      const result = await createOrUpdateLeadResponseForGmailWatcher(
        campaignId,
        senderEmail,
        messageEmail,
        actualEmail,
        subject,
        body,
        messageId,
        leadId,
        date,
        plainBody,
        currentMessageId,
        false, // isBounced
        ccList,
        forwardedTo
      );

      const campaignData = await campaign.findById(campaignId).select(
        'notificationEmail senderName senderTitle companyName productDesc campaignDesc testimonials emailStructure clientEmail companyWebsite replies defaultCcEmail responsibility'
      ).lean();

      await Promise.all([
        processPositiveReplyNotification(
          campaignData.notificationEmail || campaignData.clientEmail,
          messageEmail,
          result.status,
          campaignData.clientEmail
        ),
        handleUninterestedReplies(messageEmail, result.status),
        excludePositiveReplyEmail(campaignData.clientEmail, messageEmail, result.status),
        updateAnalytics(sentMail, result.status),
        leadModel.updateOne(
          {
            email: messageEmail,
            campaignIds: { $in: [campaignId] },
          },
          {
            $set: {
              responded: true,
              ...(result?.isStatusInterested && { nextFollowUpStep: '' }),
              ...(result.status === EmailStatusCategories.UNSUBSCRIBED && { unsubscribe: true }),
            },
            $push: { respondedAt: date },
          },
        )
      ])

      if (campaignData?.replies?.automaticReply == true) {
        await JobQueue.addJob('autoReplyQueue', {
          emailData,
          continues: false,
          campaignData,
          emailStatus: result.status,
        });
      }
    }
  } catch (err) {
    console.log('Error handling new message:', err);
    await webhookFailed(err);
  }
};

module.exports = {
  bouncedMessage,
  webhookFailed,
  newMessage,
  handleUninterestedReplies,
  excludePositiveReplyEmail
};
