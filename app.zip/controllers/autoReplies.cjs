const mailboxesModel = require('../models/mailboxes');
const leadResponsesModel = require('../models/leadResponses');
const AutoReplyModel = require('../models/automaticReply');
const MailScheduleModel = require('../models/MailSchedule');
const EmailStatusEvaluator = require('../utils/EmailStatusEvaluator');
const { getThreadIdFromMessageId, sendEmail } = require('../utils/GoogleUtils.cjs');
const AutoReplyPromptGenerator = require('../utils/AutoReplyPromptGenerator.cjs');
const DateAndTimeEvaluator = require('../utils/DateAndTimeEvaluator.cjs');
const UserMeetingSchedule = require('../utils/UserMeetingSchedule.cjs');
const { checkIsSlotAvailable, generateResponseBody, generateEmailHTML, generateConversationFromLeadResponses } = require('../utils/AutoReplyUtils.cjs');
const { sendEmailNotification } = require('../utils/EmailNotificationUtils.cjs');
const { handleUninterestedReplies, excludePositiveReplyEmail } = require('./campagins');
const leadModel = require('../models/lead');

const EMAIL_FOR_MANUAL_SCHEDULING = `
    <div>
        Thank you for your interest! We will reach out to you shortly to schedule a meeting.
    </div>
`;

const getMessageData = async (messageId, refreshToken) => {
    const messageData = await getThreadIdFromMessageId(messageId, refreshToken);
    if (!messageData) {
        console.error('No message found for this messageId:', messageId);
    }
    return messageData;
};

const getLeadResponse = async ({ messageId, leadResponseId }) => {
    let leadResponse;

    if(leadResponseId) {
        leadResponse = await leadResponsesModel.findById(leadResponseId);
    } else {
        leadResponse = await leadResponsesModel.findOne({ messageId });
    }

    if (!leadResponse) {
        console.error('No leadResponse found for this messageId:', messageId);
    }
    return leadResponse;
};

const getLeadData = async (leadId) => {
    return leadModel.findById(leadId).select('firstName lastName email organization linkedin_url').lean().exec();
}

const sendConnectCalendarNotification = async ({ notificationEmail, userFirstName, campaignName }) => {
    const content = `
        <div>
            <div>Hi ${userFirstName},<br/></div>
            <div>
                Your campaign ${campaignName ?? ''} is currently using the Al Auto-Reply feature. While connecting your calendar is <i>optional</i>, doing so can significantly improve the efficiency of your Al in booking meetings.<br/>
            </div>
            <div>To connect your calendar, please click here to access your dashboard.<br/></div>
            <div>Best regards,</div>
            <div>The B2B Rocket Team<br/></div>
            <div>Not sure how to connect your calendar? Check out this article on connecting your calendar from our help center.</div>
        </div>
    `;

    await sendEmailNotification({
        email: notificationEmail,
        subject: "Connect Your Calendar for Better Auto-Reply",
        content,
    });
}

const sendManualMeetingEmail = async ({
    messageEmail,
    refreshToken,
    messageId,
    threadId,
    ccEmails,
}) => {
    await sendEmail({
        to: messageEmail,
        subject: "Scheduling Your Meeting",
        message: EMAIL_FOR_MANUAL_SCHEDULING,
        refreshToken,
        messageId,
        threadId,
        cc: ccEmails,
    })
}

const generateMeetingInfoEmailContent = async (leadResponse) => {
    const conversationContent = generateConversationFromLeadResponses(leadResponse);
    const leadData = await getLeadData(leadResponse.leadId);
    //Title:    ${leadData}\n
    const content = `
        <div>Hey User<br /></div>
        <div>A Prospect is interested in scheduling a meeting with you. <br /></div>
        <div>Here is contact info:</div>
        <pre>
Name:     ${leadData.firstName} ${leadData.lastName}
Company:  ${leadData.organization}
Linkedin: ${leadData.linkedin_url || '-'}
Email:    ${leadData.email}
        </pre>
        <div><br /></div>
        <div>Here is conversation thread:</div>
        ${conversationContent}
    `;

    return content;
}

const sendMeetingInfoNotification = async (leadResponse, notificationEmail) => {
    const content =  await generateMeetingInfoEmailContent(leadResponse);

    await sendEmailNotification({
        email: notificationEmail,
        subject: "Connect Your Calendar for Better Auto-Reply",
        content,
    });
}

const GetDateAndTime = async (requiredData) => {
    const {
        senderName,
        senderEmail,
        messageEmail,
        companyName,
        body,
        clientEmail,
        refreshToken,
        subject,
        threadId,
        bcc = [],
        messageId,
        _id: campaignId,
        cc: ccEmails,
    } = requiredData;

    try {
        const extractedTime = await DateAndTimeEvaluator.evaluateDateAndTimeFromEmail(body);

        // Prepare meeting data
        const meetingData = {
            client_email: clientEmail,
            email: senderEmail,
            lead_email: messageEmail,
            summary: `${companyName} <> undefined`,
            time: extractedTime,
            campaign_id: campaignId,
            description: "Discuss our offerings and how we can help you.",
            location: { description: "Virtual Meeting" },
            attendees: { invite: [{ email: messageEmail }] },
        };

        // Get available calendar slots
        const calendarSlotsResult = await UserMeetingSchedule.getCalendarSlots(clientEmail, campaignId, true);

        if(calendarSlotsResult === 'Calendar not connected!') {
            return {
                isCalendarNotConnected: true,
                mailSent: false,
            };
        }

        const isSlotAvailable = checkIsSlotAvailable(calendarSlotsResult, extractedTime);

        // Generate email response body
        const responseBodyData = {
            calendarSlotsResult,
            isSlotAvailable,
            extractedTime,
            senderName,
            subject,
        };
        const responseBody = generateResponseBody(responseBodyData);

        // Schedule meeting if slot is available and send email
        if (isSlotAvailable) {
            const meetingResult = await UserMeetingSchedule.addMeetingScheduleByCronofy(meetingData);
            if (meetingResult === "Meeting added successfully") {
                await sendEmail({
                    refreshToken,
                    to: messageEmail,
                    subject,
                    message: responseBody,
                    threadId,
                    cc: ccEmails,
                    bcc,
                    messageId,
                });
            }
            console.log("Meeting scheduled and email sent.");
            return {
                isCalendarNotConnected: false,
                mailSent: true,
            };
        } else {
            // Send email without scheduling if no slot is available
            await sendEmail({
                refreshToken,
                to: messageEmail,
                subject,
                message: responseBody,
                threadId,
                cc: ccEmails,
                bcc,
                messageId,
            });
            console.log("Email sent without scheduling.");
            return {
                isCalendarNotConnected: false,
                mailSent: true,
            };
        }
    } catch (error) {
        console.error("Error in GetDateAndTime function:", error);
        return {
            isCalendarNotConnected: false,
            mailSent: false,
        };
    }
};


const generateResponseContent = async ({ status, campaignData, messageData, refreshToken, initialEmail }) => {
    let gptRawResponse = null;
    let result = { mailSent: false, isCalendarNotConnected: false }

    if (status === "Meeting Booked") {
        result = await GetDateAndTime({
            ...campaignData,
            ...initialEmail,
            threadId: messageData?.threadId,
            refreshToken,
        });
    }

    if(!result.isCalendarNotConnected) {
        gptRawResponse = await AutoReplyPromptGenerator.generateAutoReply(status, campaignData, initialEmail);
    }

    return { gptRawResponse, ...result };
};

const updateLeadResponse = async (leadResponse, data) => {
    const { messageId, messageEmail, senderEmail, subject, ccEmails, messageContent, status } = data;
    const conversation = {
        subject,
        messageId,
        email: messageEmail,
        senderEmail,
        date: new Date().toISOString(),
        cc: ccEmails,
        body: generateEmailHTML(messageContent),
    };

    leadResponse.cc.push(...ccEmails);
    leadResponse.status = status;
    leadResponse.conversations.push(conversation);
    await leadResponse.save();
};

const updateAutoReply = async ({ threadId, leadId, campaignId, leadResponseId }) => {
    const query = { threadId };
    const update = {
        $setOnInsert: {
            threadId,
            campaignId,
            leadId,
            leadResponseId,
        },
    };
    const options = { upsert: true, setDefaultsOnInsert: true };
    await AutoReplyModel.findOneAndUpdate(query, update, options);
}

const updateDbForAutoReply = async ({ leadResponse, messageId, messageEmail, senderEmail, subject, ccEmails, messageContent, status, threadId, campaignId }) => {
    await Promise.all([
        updateLeadResponse(leadResponse, {
            messageId,
            messageEmail,
            senderEmail,
            subject,
            ccEmails,
            messageContent,
            status,
        }),
        updateAutoReply({
            threadId: threadId,
            leadId: leadResponse.leadId,
            campaignId: campaignId,
            leadResponseId: leadResponse._id,
        }),
    ]);
}

const scheduleOutOfOfficeReply = async ({ leadResponseId, refreshToken, senderEmail, messageEmail, subject, gptRawResponse, messageData, ccEmails, bcc, messageId }) => {
    const releaseTime = new Date(Date.now() + 10 * 24 * 60 * 60 * 1000); // 10 days later
    await MailScheduleModel.create({
        leadResponseId,
        refreshToken,
        from: senderEmail,
        to: messageEmail,
        subject,
        message: generateEmailHTML(gptRawResponse),
        threadId: messageData?.threadId,
        cc: ccEmails,
        bcc,
        messageId,
        releaseTime,
    });
};

const processAutoReply = async ({ status, gptRawResponse, leadResponse, campaignData, messageData, refreshToken, initialEmail, mailSent, ccEmails }) => {
    const { messageEmail, subject, bcc = [], messageId } = initialEmail;

    if (["Interested", "Meeting Booked"].includes(status) && !mailSent) {
        try {
            const sentAutoReply = await sendEmail({
                refreshToken,
                to: messageEmail,
                subject,
                message: generateEmailHTML(gptRawResponse),
                threadId: messageData?.threadId,
                cc: ccEmails,
                bcc,
                messageId
            });

            if(sentAutoReply) {
                await updateDbForAutoReply({
                    leadResponse,
                    messageId,
                    messageEmail,
                    senderEmail: initialEmail.senderEmail,
                    subject,
                    ccEmails,
                    messageContent: gptRawResponse,
                    status,
                    threadId: messageData?.threadId,
                    campaignId: campaignData.campaignId,
                });
            }

        } catch (err) {
            console.error('Error sending autoReply:', err);
        }
    } else if (campaignData.replies?.autoOutOfOfficeReply && status === 'Out Of Office') {
        await scheduleOutOfOfficeReply({
            leadResponseId: leadResponse._id,
            refreshToken,
            senderEmail: initialEmail.senderEmail,
            messageEmail,
            subject,
            gptRawResponse,
            messageData,
            ccEmails,
            bcc,
            messageId
        });
    }
};

const processNotConnectedCalendarAutoReply = async ({ campaignData, leadResponse, refreshToken, messageData, messageEmail, messageId, ccEmails, status }) => {
    const { threadId } = messageData;
    const { responsibility: campaignName, senderName, notificationEmail, clientEmail } = campaignData;
    const notificationEmailAddress = notificationEmail || clientEmail;

    try {

        await Promise.all([
            sendConnectCalendarNotification({
                userFirstName: senderName.split(' ')[0],
                notificationEmail: notificationEmailAddress,
                campaignName,
            }),
            sendManualMeetingEmail({ messageEmail, refreshToken, messageId, threadId, ccEmails }),
            sendMeetingInfoNotification(leadResponse, notificationEmailAddress)
        ])

        await updateDbForAutoReply({
            leadResponse,
            messageId,
            messageEmail,
            senderEmail: leadResponse.senderEmail,
            subject: leadResponse.subject,
            ccEmails,
            messageContent: EMAIL_FOR_MANUAL_SCHEDULING,
            status,
            threadId,
            campaignId: campaignData.campaignId,
        });

    } catch(error) {
        console.log(error)
        throw new Error('Error sending auto-reply for no connected calendar')
    }
}

const handleAutoReply = async (data) => {
    const { emailData: initialEmail, campaignData, refreshToken, emailStatus, leadResponseId } = data;
    const { messageId, cc = [], messageEmail } = initialEmail;
    let ccEmails = [...cc];

    if (campaignData.replies?.includeEmailAsCC) {
        ccEmails.push(campaignData.defaultCcEmail || campaignData.clientEmail);
    }

    const [
        messageData,
        leadResponse,
    ] = await Promise.all([
        data.messageData ? Promise.resolve(data.messageData) : getMessageData(messageId, refreshToken),
        getLeadResponse({ messageId, leadResponseId }),
    ]);

    if (!campaignData || !messageData || !leadResponse) return;

    // const { status } = leadResponse;

    const { gptRawResponse, isCalendarNotConnected, mailSent } = await generateResponseContent({
        status: emailStatus,
        campaignData,
        messageData,
        refreshToken,
        initialEmail
    });

    if(isCalendarNotConnected) {
        await processNotConnectedCalendarAutoReply({
            status: emailStatus,
            campaignData,
            leadResponse,
            refreshToken,
            messageData,
            messageEmail,
            messageId,
            ccEmails,
        });
        return;
    }

    await processAutoReply({
        status: emailStatus,
        mailSent,
        gptRawResponse,
        leadResponse,
        campaignData,
        messageData,
        refreshToken,
        initialEmail,
        ccEmails,
    });
};

const autoReplyMessageProcessor = async (data) => {
    console.log('hello world this is test');
    try {
        const { emailData, continues, campaignData } = data;
        const { provider_data: { refresh_token: refreshToken } } = await mailboxesModel.findOne({ senderEmail: emailData.senderEmail }).select('provider_data').lean();

        if (!refreshToken) {
            console.error('No Refresh token found for', emailData.senderEmail);
            return;
        }

        if (!continues) {
            await handleAutoReply({
                emailData,
                campaignData,
                refreshToken,
                messageData: null,
                emailStatus: data.emailStatus,
                leadResponseId: null,
            });
            return;
        }


        const messageData = await getMessageData(emailData.messageId, refreshToken);
        const emailStatus = await EmailStatusEvaluator.evaluateEmailReply(emailData.body ?? '');
        const automaticReply = await AutoReplyModel.findOne({
            threadId: messageData?.threadId,
        }).populate(
            'campaignId',
            'senderName senderTitle companyName productDesc campaignDesc testimonials emailStructure clientEmail notificationEmail companyWebsite replies defaultCcEmail responsibility',
        ).lean();

        if (!automaticReply) {
            console.error('No automaticReply/Email found for this threadId', messageData.threadId, emailData.messageId);
            return;
        }

        const { continuesAutoReplies, autoOutOfOfficeReply } = automaticReply.campaignId?.replies ?? {};

        if (continuesAutoReplies || autoOutOfOfficeReply) {
            await Promise.all([
                handleUninterestedReplies(emailData.messageEmail, emailStatus),
                excludePositiveReplyEmail(
                    automaticReply.campaignId.clientEmail,
                    emailData.messageEmail,
                    emailStatus
                )
            ])
            await handleAutoReply({
                emailData,
                campaignData: automaticReply.campaignId,
                refreshToken,
                messageData,
                emailStatus,
                leadResponseId: automaticReply.leadResponseId,
            });
        }

    } catch (error) {
        console.log('Error handling new message:', error);
    }
};

module.exports = {
    autoReplyMessageProcessor,
}
