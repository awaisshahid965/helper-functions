const mongoose = require('mongoose');
const mailboxLogsSchema = new mongoose.Schema({
  mailboxId: { type: mongoose.Schema.Types.ObjectId, required: true },
  // campaignId: { type: mongoose.Schema.Types.ObjectId, required: true },
  logs: {
    type: Object,
    default: {},
  },
});
const mailboxLogsModel = mongoose.model('mailbox_logs', mailboxLogsSchema);
module.exports = mailboxLogsModel;