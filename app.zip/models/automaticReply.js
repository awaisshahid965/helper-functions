const mongoose = require('mongoose');

const autoReplySchema = new mongoose.Schema({
  leadId: {
    type: String,
  },
  leadResponseId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'lead_responses',
  },
  campaignId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'campaign',
  },
  threadId: {
    type: String,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

autoReplySchema.index({ campaignId: 1 });

const AutoReplyModel = mongoose.model('AutoReply', autoReplySchema);
module.exports = AutoReplyModel;
