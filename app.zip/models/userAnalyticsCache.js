const mongoose = require("mongoose");

const userAnalyticsSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user_registered",
    },
    leadsGenerated: {
      type: Number,
      default:0
    },
    sent: {
      type: Number,
      default:0
    },
    delivered: {
      type: Number,
      default:0
    },
    opened: {
      type: Number,
      default:0
    },
    clicked: {
      type: Number,
      default:0
    },
    pageEngage: {
      type: Number,
      default:0
    },
    pageEngageRate: {
      type: Number,
      default:0
    },
    avgTimeSpendOnPage: {
      type: Number,
      default: 0,
      required: false,
    },
    videoViews: {
      type: Number,
      default: 0,
      required: false,
    },
    videoViewsRate: {
      type: Number,
      default: 0,
      required: false,
    },
    avgVideoViewLength: {
      type: Number,
      default: 0,
      required: false,
    },
    aiConversation: {
      type: Number,
    default:0
    },
    health: {
      type: Number,
      default:0
    },
    meetingPerfomance: {
      type: Number,
      default:0
    },
    totalAiAgents: {
      type: Number,
      default:0
    },
    workingAgents:{
      type: Number,
      default:0,
    },
    mailboxesAssigned:{
      type:Number,
      default:0
    },
    unsubscribed:{
      type:Number,
      default:0
    },
    webSiteVisit: {
      type: Number,
      default: 0,
    },
    dateAdded:{
     type:Date,
    default:Date.now(),
    } 
  },
  {
    timestamps: true,
  }
);
userAnalyticsSchema.index({dateAdded:1});
userAnalyticsSchema.index({user:1 });

const userAnalytics = mongoose.model("userAnalyticsCache", userAnalyticsSchema);

module.exports = userAnalytics;
