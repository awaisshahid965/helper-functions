const mongoose = require('mongoose');
const exclusionListSchema = new mongoose.Schema({
  clientEmail: { type: String, required: true },
  level: { type: String, enum: ['USER', 'CAMPAIGN'], default: 'USER' },
  emails: { type: [Object], default: [] },
  domains: { type: [Object], default: [] },
});
const ExclusionListModel = mongoose.model('exclusion_list', exclusionListSchema);

module.exports = ExclusionListModel;
