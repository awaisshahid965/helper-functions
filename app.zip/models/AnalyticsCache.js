const mongoose = require('mongoose');

const AnalyticsCacheSchema = new mongoose.Schema(
  {
    date: {
      type: Date,
      required: true,
    },
    campaignId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    clientEmail: {
      type: String,
      required: false,
    },
    analytics: {
      emailSent: {
        type: Number,
        required: true,
        default: 0,
      },
      leadsGenerated: {
        type: Number,
        required: true,
        default: 0,
      },
      emailDelivered: {
        type: Number,
        required: true,
        default: 0,
      },
      emailOpened: {
        type: Number,
        required: true,
        default: 0,
      },
      emailClicked: {
        type: Number,
        required: true,
        default: 0,
      },
      conversations: {
        type: Number,
        required: true,
        default: 0,
      },
      meetings: {
        type: Number,
        required: true,
        default: 0,
      },

      initial: {
        type: Object,
        required: true,
        default: {},
      },
      conversation: {
        type: Object,
        required: true,
        default: {},
      },
      meetingBooked: {
        type: Object,
        required: true,
        default: {},
      },
      meetingMissed: {
        type: Object,
        required: true,
        default: {},
      },

      initialSeqStats: {
        type: Object,
        required: true,
        default: {},
      },
      conversationSeqStats: {
        type: Object,
        required: true,
        default: {},
      },
      meetingBookedSeqStats: {
        type: Object,
        required: true,
        default: {},
      },
      meetingMissedSeqStats: {
        type: Object,
        required: true,
        default: {},
      },

      unSubscribeCount: {
        type: Number,
        default: 0,
      },
      webSiteVisit: {
        type: Number,
        default: 0,
      },
    },
    dataExists: {
      type: Boolean,
      required: true,
      default: true,
    },
  },
  {
    timestamps: true,
  },
);

const AnalyticsCache = mongoose.model('analytics_caches', AnalyticsCacheSchema);

module.exports = {AnalyticsCache};
