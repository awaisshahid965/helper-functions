
const mongoose = require('mongoose');
const EmailStatusEvaluator = require('../utils/EmailStatusEvaluator');

const leadResponsesSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    index: true
  },
  senderEmail: {
    type: String,
    required: true,
    index: true
  },
  actualEmail: {
    type: String,
    default: '',
  },
  messageId: {
    type: String,
    index: true
  },
  campaignId: {
    type: String
  },
  leadId: {
    type: String
  },
  subject: {
    type: String
  },
  body: {
    type: String
  },
  conversations:{
    type: Array
  },
  cc:{
    type: Array
  },
  bcc:{
    type: Array
  },
  messageDate: {
    type: String
  },
  isDeleted: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: [...EmailStatusEvaluator.getAllStatuses(), 'not_processed'],
  }
});

const leadResponsesModel = mongoose.model('lead_responses', leadResponsesSchema);
leadResponsesModel.schema.index({ senderEmail: 1, email: 1, messageId: 1 }, { unique: true });

module.exports = leadResponsesModel;
