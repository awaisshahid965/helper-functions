const mongoose = require('mongoose');
const blacklistSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true }, // Each email should be unique
    admin: { type: String, required: true },
  },
  { timestamps: true },
);
const blacklistModel = mongoose.model('blacklist', blacklistSchema);
module.exports = blacklistModel;