const mongoose = require('mongoose');

const UserRegistered = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  companyName: {
    type: String,
    required: true,
  },
  companyAddress: {
    type: String,
    required: false,
  },
  customerId: {
    type: String,
    default:null
  },
  email: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: false,
  },
  customerId: {
    type: String
  },
  profile_image: {
    type: String,
    required: false,
  },
  organization_id: {
    type: String,
    required: true,
  },
  plan: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    required: true,
  },
  campaginManager: {
    type: String,
    required: true,
  },
  campaginManagerEmail: {
    type: String,
    required: false,
  },
  freeSubscription: {
    type: Boolean,
    default: false
  },
  accountStatus: {
    type: Number,
    required: false,
  },
  extra: {
    type: Object,
    default: {},
    required: false,
  },
  avatar: {
    type: String,
    required: false,
  },
  meeting_link: {
    type: String,
    required: false,
  },
  accessToken: {
    type: String,
    required: false,
  },
  token: {
    type: String,
    required: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const User_registered = mongoose.model('user_registered', UserRegistered);
module.exports = User_registered;
