const mongoose = require('mongoose');

const leadResponsesErrorSchema = new mongoose.Schema({
  errorPayload: {
    type: String,
    required: true,
  },
});

const LeadResponsesErrorModel = mongoose.model('lead_responses_error', leadResponsesErrorSchema);

module.exports = LeadResponsesErrorModel;
