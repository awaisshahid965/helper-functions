const mongoose = require('mongoose');

const sentSchema = new mongoose.Schema({
  _id: { type: mongoose.Schema.Types.ObjectId, require: true },
  partMessageId: { type: String, default: null },
  messageId: { type: String, index: true },
  campaignId: { type: String, required: true },
  from: { type: String, required: true },
  to: { type: String, required: true },
  leadId: {
    type: mongoose.Schema.Types.ObjectId,
    default: null,
  },
  email: {
    type: Object,
    required: true,
  },
  followUp: {
    type: Boolean,
    default: false,
  },
  isBounced: {
    type: Boolean,
    default: false,
  },
  opened: {
    type: [Date],
    default: [],
  },
  clicked: {
    type: [Date],
    default: [],
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  sequence: {
    type: String,
    enum: ['initial', 'conversation', 'meetingBooked', 'meetingMissed'],
    required: true,
  },
  step: {
    type: String,
    enum: ['1', '2', '3', '4'],
    required: true,
  },
});

sentSchema.index({ createdAt: 1 });
const Sent_Model = mongoose.model('sentemails', sentSchema);
module.exports = Sent_Model;
