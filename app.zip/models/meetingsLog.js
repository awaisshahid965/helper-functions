const mongoose = require('mongoose');

const Schema = mongoose.Schema;
const schema = new Schema(
  {
    cronofy : {
        payload : {
            type : Object,
            default : {}
        },
        user : {
            type : Object,
                default : {}
        },
        accessToken : String,
        availableCalender : {
            type : Object,
            default : {}
        },
        selectedCalender : {
            type : Object,
            default : {}
        },
        webhookPayload : {
            type : Object,
            default : {},
        },
        webhookData : {
            payload : {
                type : Object,
                default : {}
            },
            meetingData : {
                type : Object,
                default : {}
            },
            error : {
                type : Object,
                default: null
            }
        },
        webhookResponse : {
            type : Object,
            default : {},
        },
        leadsData : {
            type : Object,
            default : {}
        },
        response : {
            type: Object,
            default: {},
        },
        error : {
            type : Object,
            default: null
        }
    },
    addUserMeeting : {
        payload : {
            type : Object,
            default : {}
        },
        upsertUserMeeting : {
            type: Object,
            default : {}
        },
        analyticsCacheData : {
            type : Object,
            default : {}
        },
        emailLogUpdate : {
            type : Object,
            default : {}
        },
        response : {
            type: Object,
            default: {},
        },
        error : {
            type : Object,
            default: null
        },
        errorInside : {
            type : Object,
            default: null
        },
    },
  },
  {
    timestamps: true,
  },
);

const meetingLog = mongoose.model('meetingLog', schema);
module.exports = meetingLog;
