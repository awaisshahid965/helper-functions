const mongoose = require('mongoose');

const campaignSchema = new mongoose.Schema(
  {
    organisationName: {
      type: String,
      required: false,
    },
    clientEmail: {
      type: String,
      required: true,
    },
    order: {
      type: Number,
    },
    //(userSubscriptionId) this is relate stripeModels (userSubscription) for user plan purchase, added by gaurav
    // and check the record for adding agents by this id
    userSubscriptionId: {
      type: String,
      // required: true
    },
    videoId: {
      type: String,
    },
    videoToken: {
      type: String,
    },
    videoUrl: {
      type: String,
    },
    // Enterpice user identification
    isEnterprise: {
      type: Boolean,
      default: false,
    },
    campaignStatus: {
      type: Boolean,
      default: false,
    },
    paused: {
      type: Boolean,
      default: true,
    },
    archived: {
      type: Boolean,
      default: false,
    },
    operationStat: {
      type: {
        // No. of leads to fetch today, could be inconsistent: is handled in Email service !
        // remToday: {
        //   type: Number,
        // },
        // lastActive: {
        //   type: Date,
        // },
        // leadsGen: {
        //   type: Number,
        // },
        // // page param in the apollo req, helps managing duplicacy
        // nextPage: { type: Number },
        // nextDomainPage: { type: Number },
        // totalEmailed: { type: Number },
        // emailsOpened: { type: Number },
        // meetings: { type: Number },
      },
      required: false,
      default: {
        leadsGen: 0,
        nextPage: 1,
        nextDomainPage: 1,
        totalEmailed: 0,
        emailsOpened: 0,
        meetings: 0,
      },
    },
    apollo: {
      type: Object,
    },
    dataProvider: {
      type: String,
      enum: ['APOLLO', 'ROCKETREACH'],
      required: true,
    },
    subscription: {
      type: {
        dailyLimit: {
          type: Number,
          required: false,
        },
      },
      required: false,
    },
    addFilters: {
      type: {
        compSize: { type: [String] },
        keywords: { type: [String] },
        revenue: { type: [Number] },
        funding: { type: [Number] },
        location: { type: [String] },
        blockedDomains: { type: [String] },
        blockedIndustries: { type: [String] },
        blockedLocations: { type: [String] },
        blockedKeywords: { type: [String] },
        customCompSize: {
          min: { type: [String] },
          max: { type: [String] },
        },
      },
      default: {
        compSize: [],
        keywords: [],
        revenue: [],
        funding: [],
        location: [],
        blockedDomains: [],
        blockedIndustries: [],
        blockedLocations: [],
        blockedKeywords: [],
      },
    },
    avoidLeadsFromDomains: {
      type: [
        {
          domain: {
            type: String,
            required: false,
          },
          count: {
            type: Number,
            default: 0,
            required: false,
          },
          lastSent: {
            type: Date,
            required: false,
          },
        },
      ],
      default: [],
    },
    avoidEmailToDomains: {
      type: [
        {
          domain: {
            type: String,
            required: false,
          },
          count: {
            type: Number,
            default: 0,
            required: false,
          },
          lastSent: {
            type: Date,
            required: false,
          },
        },
      ],
      default: [],
    },
    leadSource: {
      type: String,
      enum: ['csv', 'auto'],
      default: 'auto',
    },
    uploadedLeads: {
      type: [Object],
      default: [],
    },
    leads: {
      // type: [
      //   {
      //     firstName: { type: String, required: true },
      //     lastName: { type: String, required: true },
      //     email: { type: String, required: true },
      //     linkedin_url: { type: String, required: true },
      //     description: { type: String, required: true },
      //     organization: { type: String, required: true },
      //     industry: { type: String, required: true },
      //     address: {
      //       type: {
      //         city: { type: String, required: true },
      //         state: { type: String, required: true },
      //         country: { type: String, required: true },
      //       },
      //     },
      //     // 1 -> sent, 0 -> not sent, 2 -> blocked
      //     emailStatus: { type: Number, default: 0 },
      //     emailBody: { type: String },
      //     // set to true once email is sent
      //     followUpRequired: { type: Boolean, default: false },
      //     opened: { type: Boolean, default: false },
      //     sentAt: { type: Date },
      //   },
      // ],
      type: [mongoose.Schema.Types.ObjectId],
      default: [],
    },
    senderName: {
      type: String,
      required: false,
    },
    senderTitle: {
      type: String,
      required: false,
    },
    companyName: {
      type: String,
      required: false,
    },
    companyLocation: {
      type: Array,
      required: true,
    },
    title: {
      type: String,
      required: false,
    },
    productDesc: {
      type: String,
      required: false,
    },
    expertise: {
      type: String,
      default: '',
    },
    companyWebsite: {
      type: String,
      default: '',
    },
    testimonials: {
      type: String,
      default: '',
    },
    testimonials_v2: {
      type: [Object],
      default: [],
    },
    industry: {
      type: [String],
      required: false,
    },
    targets: {
      type: [String],
      required: false,
    },
    sicCode: {
      type: [Number],
      required: true,
    },
    naicsCode: {
      type: [Number],
      required: true,
    },
    additionalFilters: {
      type: Object,
    },
    campaignDesc: {
      type: String,
      required: false,
    },
    link: {
      url: { type: String, default: '' },
      enabled: { type: Boolean, default: false },
    },
    // Indicates status for leads generation process
    // status -> 0: failed, 1: in-progress, 2: success
    status: {
      type: Number,
      default: 1,
    },
    testimonials_v2: [
      {
        testimonial: { type: String },
        clientName: { type: String },
        clientTitle: { type: String },
        clientCompanyName: { type: String },
      },
    ],
    analytics: {
      type: Object,
      default: {},
    },
    // New fields based on new payload
    responsibility: { type: String },
    prospectData: {
      includeLocation: { type: Boolean, default: false },
      includeSkills: { type: Boolean, default: false },
      includeEducation: { type: Boolean, default: false },
      includeJobHistory: { type: Boolean, default: false },
    },
    companyData: {
      includeCompanyDescription: { type: Boolean, default: false },
      includeIndustry: { type: Boolean, default: false },
      includeFunding: { type: Boolean, default: false },
      includeYearFounded: { type: Boolean, default: false },
      includeRevenue: { type: Boolean, default: true },
      includeNumberOfEmployees: { type: Boolean, default: true },
      includeSicCodes: { type: Boolean, default: true },
    },
    ctaSelection: { type: String, required: true },
    emailSubject: { type: [String] },
    emailStructure: {
      purpose: { type: String },
      creativeness: { type: String },
      length: { type: String },
      tone: { type: String },
      language: { type: String },
      customLanguage: { type: String },
    },
    emailContent: {
      opening: { type: String },
      connecting: { type: String },
      body: { type: String },
      ending: { type: String },
    },
    customUserInput: {
      type: Object,
      default: {},
    },
    customMessage: { type: String },
    linkPlacement: {
      position: { type: String },
      selectedText: { type: String },
      customText: { type: String },
    },
    extra: {
      type: Object,
      default: {},
    },
    slotsPreset: {
      // Slots duration to show to prospect by default 30 minutes.
      type: Number,
      default: 30,
    },
    buffer: {
      isSetBuffer: {
        type: Boolean,
        default: false,
      },
      before: {
        type: Number,
        default: 0,
      },
      after: {
        type: Number,
        default: 0,
      },
    },
    notificationEmail: {
      type: String,
      default: null,
    },

    campaignSettings: {
      schedule: {
        days: { type: Array, default: [1, 2, 3, 4, 5] },
      },
      openTracking: {
        type: Boolean,
        default: true,
      },
      clickTracking: {
        type: Boolean,
        default: false,
      },
      ocuHeaders: {
        type: Boolean,
        default: false,
      },
      disclaimer: {
        enabled: { type: Boolean, default: false },
        text: { type: String, default: '' },
      },
      customDomain: {
        enabled: { type: Boolean, default: false },
        value: { type: String, default: '' },
      },
      delayEmailsInMins: {
        type: Number,
        default: 15,
      },
      minDelayInMins: {
        type: Number,
        default: 6,
      },
      unSubFooter: {
        type: Boolean,
        default: true,
      },
      unSubLink: {
        type: Boolean,
        default: true,
      },
      autoAssignMailboxes: {
        type: Number,
        default: 0,
      },
      allowDuplicates: {
        type: Boolean,
        default: false,
      },
    },
    replies: {
      automaticReply: {
        type: Boolean,
        default: false,
      },
      includeEmailAsCC: {
        type: Boolean,
        default: false,
      },
      enableEmailNotification: {
        type: Boolean,
        default: false,
      },
      autoOutOfOfficeReply: {
        type: Boolean,
        default: false,
      },
      continuesAutoReplies: {
        type: Boolean,
        default: false,
      },
      AdditionalAutoReplyInfo: {
        type: Boolean,
        default: false,
      },
    },
    lastSavedAt: {
      type: Date,
      default: Date.now,
    },
    maxMailBox: {
      type: Number,
      default: 5,
    },
    defaultCcEmail: {
      type: String,
      required: false,
    },
    autoReplyInfo: {
      type: String,
      required: false,
    },
  },
  { timestamps: true },
);
campaignSchema.index({ clientEmail: 1 });

const campaign = mongoose.model('campaign', campaignSchema);
module.exports = campaign;
