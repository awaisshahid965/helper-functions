const mongoose = require('mongoose');

const mailScheduleSchema = new mongoose.Schema({
  leadResponseId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'lead_responses',
  },
  from: {
    type: String,
  },
  to: {
    type: String,
  },
  subject: {
    type: String,
    // required: true,
  },
  message: {
    type: String,
    // required: true,
  },
  threadId: {
    type: String,
  },
  cc: {
    type: Array
  },
  bcc: {
    type: Array
  },
  messageId: {
    type: String,
  },
  releaseTime: {
    type: Date,
    // default:Date.now()
  },
  IsRelease: {
    type: Boolean,
    default: false
  }
});

const MailScheduleModel = mongoose.model('mailSchedule', mailScheduleSchema);
module.exports = MailScheduleModel;