const CAMPAIGNS_FILTER_MAPPING = {
  unsubscribe: ['unsubscribe', true],
  emailsSent: ['emailStatus', [1, 2]],
  views: ['opened', true],
  // clickedAt: ['clickedAt', 0],
  // conversationAt: ['conversationAt', 0],
};

module.exports = {CAMPAIGNS_FILTER_MAPPING};
