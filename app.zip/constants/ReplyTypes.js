const ReplyTypes = {
    NEW: 'new',
    BOUNCED: 'bounced',
    AUTO: 'auto',
}

module.exports = {
    ReplyTypes,
}
