const EmailStatusCategories = Object.freeze({
    LEAD: 'Lead',
    INTERESTED: 'Interested',
    MEETING_BOOKED: 'Meeting Booked',
    MEETING_COMPLETED: 'Meeting Completed',
    WON: 'Won',
    OUT_OF_OFFICE: 'Out Of Office',
    WRONG_PERSON: 'Wrong Person',
    NOT_INTERESTED: 'Not Interested',
    LOST: 'Lost',
    BOUNCED: 'Bounced',
    UNSUBSCRIBED: 'Unsubscribed',
    OTHER: 'Other',
});

module.exports = {
    EmailStatusCategories
}