const express = require('express');
const cors = require('cors');
const http = require('http');
const mongoose = require('mongoose');
const morgan = require('morgan');
require('dotenv').config();
require('colors');

// Route Files
const main = require('./routes/main');
const { mailScheduleCron } = require('./cron/outOfOffice.cron.cjs');

// DB Connection work
const db = require('./config/keys').MongoURI;
mongoose
  .connect(db, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log('MongoDB Connected'.green.bold);
    mailScheduleCron();
    // const clearPollInt = startPolling();
  })
  .catch((err) => console.log(err));

const app = express();
const server = http.createServer(app);
app.use(morgan('dev'));
app.use(
  cors({
    origin: true,
    credentials: true,
  }),
);

app.use(express.static('public'));

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// test route
app.get('', (req, res) => {
  res.send('Working');
});

// Routing for API Service
app.use('/api/v1/main', main);

// import queue config to start queues
require('./config/startQueue');

const PORT = process.env.PORT || 8090;

server.listen(PORT, console.log(`Server running on port ${PORT}`));
