require('dotenv').config();
const { autoReplyMessageProcessor } = require('./controllers/autoReplies.cjs');
const mongoose = require("mongoose");
const db = require('./config/keys').MongoURI;

const nonContinuesAutoReplyData = {
    "emailData": {
        "messageId": "<6541923e-ba25-2727-dd7a-86b14a884102@gmail.com>",
        "senderEmail": "gaminghawkeye14@gmail.com",
        "messageEmail": "akshayvaghasiya772@gmail.com",
        "subject": "Re: Explore with Lead finder",
        "currentMessageId": "<6541923e-ba25-2727-dd7a-86b14a884102@gmail.com>",
        "isBounce": false,
        "cc": [],
        "body": "<div style=\"white-space: pre-wrap; font-size: 14px; text-align: left; font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji';\">can you schedule one meeting with me On MON, AUG 26TH 8:30 AM</div>",
        "plainBody": "Hello, I'm interested!\n\nOn Wed, Jul 24, 2024 at 5:29 PM jenis dhameliya <gaminghawkeye14@gmail.com>\nwrote:\ncan you schedule one meeting with me?\n>"
    },
    "continues": false,
    "emailStatus": "Meeting Booked",
    "campaignData": {
        "emailStructure": {
            "creativeness": "Standard",
            "length": "Standard (150)",
            "tone": "Business Professional",
            "language": "default",
            "customLanguage": "",
            "purpose": "Product/Service Pitch"
        },
        "replies": {
            "automaticReply": true,
            "includeEmailAsCC": false,
            "enableEmailNotification": false,
            "autoOutOfOfficeReply": true,
            "continuesAutoReplies": true,
            "AdditionalAutoReplyInfo": false
        },
        "companyWebsite": "https://b2brocket.ai/",
        "testimonials": "B2B Rocket identified opportunities for Company XYZ, which generated in revenue over 6 months.\n\n",
        "notificationEmail": "akshayvaghasiya772@gmail.com",
        "_id": "6669801fecd4fa006aeb911d",
        "clientEmail": "gaminghawkeye14@gmail.com",
        "senderName": "Test",
        "senderTitle": "Developer",
        "companyName": "Lead finder",
        "productDesc": "We provide test solutions, offering streamlined procurement, advanced analytics, and integrated CRM systems to boost efficiency and support strategic business decisions.\n\n",
        "campaignDesc": "test leverages AI technology to streamline business-to-business transactions, enhance customer engagement, and optimize supply chain operations for improved efficiency and profitability.",
        "defaultCcEmail": "gaminghawkeye14@gmail.com"
    }
}

const continuesAutoReplyData = {
    "emailData": {
        "messageId": "<CADBKGW3+wTd2oWeh-y45Wn9G5XouuOTCQOYzrTT1GqXGZMXraw@mail.gmail.com>",
        "senderEmail": "gaminghawkeye14@gmail.com",
        "messageEmail": "akshayvaghasiya772@gmail.com",
        "subject": "Re: Explore with Lead finder",
        "currentMessageId": "<CADBKGW3+wTd2oWeh-y45Wn9G5XouuOTCQOYzrTT1GqXGZMXraw@mail.gmail.com>",
        "isBounce": false,
        "cc": [],
        "body": "<div style=\"white-space: pre-wrap; font-size: 14px; text-align: left; font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji';\">can you schedule one meeting with me On MON, AUG 26TH 10:30 AM</div>",
        "plainBody": "Hello, I'm interested!\n\nOn Wed, Jul 24, 2024 at 5:29 PM jenis dhameliya <gaminghawkeye14@gmail.com>\nwrote:\ncan you schedule one meeting with me?\n>"
    },
    "continues": true,
    "campaignData": null,
}

;(async () => {

    try { //191a2160923f7bbe threadid

        // connect mongodb
        await mongoose.connect(db, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
        })

        // call code here
        const continues = true;
        await autoReplyMessageProcessor(continues ? continuesAutoReplyData : nonContinuesAutoReplyData)

    } catch(err) {
        console.error(err)
    } finally {
        await mongoose.disconnect()
    }

})()