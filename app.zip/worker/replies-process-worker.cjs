const connect = require('../config/db.cjs');
const { newMessage, bouncedMessage } = require('../controllers/campagins');
const { ReplyTypes } = require('../constants/ReplyTypes');
const { autoReplyMessageProcessor } = require('../controllers/autoReplies.cjs');

async function newMessageProcessor(job) {
    await connect();

    await newMessage(job.data);
    console.log('newMessage completed with result');

    return 'done';
}

async function bouncedMessageProcessor(job) {
    await connect();

    await bouncedMessage(job.data);
    console.log('bouncedMessage completed with result');

    return 'done';
}

async function autoReplyProcessor(job) {
    await connect();

    await autoReplyMessageProcessor(job.data);
    console.log('autoReplyMessageProcessor completed with result');

    return 'done';
}

function getRepliesProcessor(replyType) {
    const replyTypeHandler = {
        [ReplyTypes.NEW]: newMessageProcessor,
        [ReplyTypes.BOUNCED]: bouncedMessageProcessor,
        [ReplyTypes.AUTO]: autoReplyProcessor,
    };

    return replyTypeHandler[replyType];
}

module.exports = {
    getRepliesProcessor,
}
