const Redis = require('ioredis');

let redisClient = null;
const redisHost = 'eewebhook.redis.cache.windows.net';
const redisPort = 6380;
const redisPassword = 'PAXjJbidMSviMy7qcvBJAURBZh65hRt25AzCaMDStlQ=';

// Redis configuration
const redisConfig = {
    host: redisHost,
    port: redisPort,
    password: redisPassword,
    maxRetriesPerRequest: null,
    connectTimeout: 60000,
    retryStrategy: times => {
        // Reconnect after a delay if connection fails
        const delay = Math.min(times * 50, 2000);
        return delay;
    },

    tls: {},
};

function getRedisClient() {
    if (!redisClient) {
        redisClient = new Redis(redisConfig);

        redisClient.on('error', (err) => {
            console.error('Redis error:', err);
        });
    }

    return redisClient;
}

module.exports = getRedisClient;
