module.exports = {
  MongoURI: process.env.MONGO_URI,
};
