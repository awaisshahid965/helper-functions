// const JobQueue = require('../utils/JobQueue.cjs');

// JobQueue.processJob('bouncedMessageQueue', 1);

// JobQueue.processJob('newMessageQueue', 1);

// JobQueue.processJob('autoReplyQueue', 1);

const { ReplyTypes } = require("../constants/ReplyTypes");
const { processQueue } = require("../utils/bullmqUtils.cjs");
const { getRepliesProcessor } = require("../worker/replies-process-worker.cjs");

processQueue('newMessageQueue', getRepliesProcessor(ReplyTypes.NEW));
processQueue('bouncedMessageQueue', getRepliesProcessor(ReplyTypes.BOUNCED));
processQueue('autoReplyQueue', getRepliesProcessor(ReplyTypes.AUTO));

module.exports = {}
