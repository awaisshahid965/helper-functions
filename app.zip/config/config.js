require('colors');

const mailBoxesPerCamp = 10;
const maxDailyEmailLimitPerMailbox = 30;
const maxDailyEmailsPerCamp = mailBoxesPerCamp * maxDailyEmailLimitPerMailbox; // mailboxes * emails per day
const rrServiceDowntimeToleranceInDays = 0.5;

// ---------------------------Switch PRODUCTION / LOCAL------------------------------------------------
// Also check line 40

// LOCAL
// const frontEndURL = 'http://localhost:3000';

// PRODUCTION
const frontEndURL = 'https://app.b2brocket.ai';
const API_SERVICE_BACKEND = "https://api.b2brocket.ai/api/v1/main";
const API_ADMIN_SERVICE_BACKEND ="https://apiadmin.b2brocket.ai/api/v1/main";

// ----------------------------------------------------------------------------------------------------

module.exports = {
  NODE_ID: process.env.WEBSITE_INSTANCE_ID || 'CBE_NODE_#',
  campaign: {
    INVALIDATE_CACHED_STATS_AFTER_X_HRS: 3,//minsToHrs(3), // cache is invalidated after x hrs
    config: {
      MAX_LEADS_PER_PROCESS: 150, // max leads allowed to fetch every time campaign is selected for processing
      MIN_PREFETCH_COUNT: maxDailyEmailsPerCamp * rrServiceDowntimeToleranceInDays, // n days worth of emails in excess
      DAILY_LEADS_GEN_LIMIT: 350, // obsolete, **don't use this
      MIN_LEADS: 20000, // min leads to fetch per campaign across the lifetime
      SAMPLE_SIZE: 50,
      MAX_LEADS_PER_PAGE: 100, // max leads to return per query except when exporting
      // LEADS_GEN_ALLOWED_AFTER_X_HRS: minsToHrs(10),
      maxLeadsPerDomain: 2,
      LEADS_GEN_ALLOWED_AFTER_X_HRS: 24,
      RETRY_ON_ERROR_429_AFTER_X_MINS: 60,
      POLL_EVERY_X_MINS: 2,
      LOG_ON_EVERY_N_LEADS_GEN: 500,
    },

    APOLLO: {
      API_KEY: process.env.APOLLO_API_KEY,
      BASE_URL: 'https://api.apollo.io/v1',
      PERSON_EP: '/mixed_people/search',
      COMPANY_EP: '/mixed_companies/search',
      MAX_LEADS_PER_REQUEST: 100,
    },

    ROCKET_REACH: {
      URL: 'https://api.rocketreach.co/api/v2/person/search',
      API_KEY: process.env.ROCKET_REACH_API_KEY,
      leadsToFetchPerRequest: 60,
    },
    VERIFY_EMAILS: {
      API_KEY: process.env.EMAIL_VERIFICATION_API_KEY,
      URL: 'https://api.usebouncer.com/v1.1/email/verify/batch/sync',
    },
  },
  OPEN_AI: {
    URL: 'https://api.openai.com/v1/chat/completions',
    API_KEY: process.env.OPEN_AI_API_KEY,
  },

  mailBoxes: {
    initialCap: 8,
    countPerCampaign: 10,
    maxAllowedEmailsPerDay: 20,
    maxWeekForRampUp: 10,
    googleWebAppConfig: {
      gmail_api_url: 'https://gmail.googleapis.com/gmail/v1',
      token_url: 'https://oauth2.googleapis.com/token',
      oauth_url: 'https://accounts.google.com/o/oauth2/v2/auth',
      client_id: '77176128363-v1m3kia8q8gng7ikn7fujd9h08903ttf.apps.googleusercontent.com',
      project_id: 'admin-b2b-rocket',
      auth_uri: 'https://accounts.google.com/o/oauth2/auth',
      token_uri: 'https://oauth2.googleapis.com/token',
      auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
      client_secret: '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',
      redirect_uris: [
        'http://localhost:3002/addEmail',
        'https://admin.leadingly.io/addEmail.html',
        'https://admin.b2brocket.ai/addEmail.html',
        'https://stage-adminb2brocket.vercel.app/addEmail.html',
      ],
      // redirect_uri: "https://stage-adminb2brocket.vercel.app/addEmail.html",
      // redirect_uri: "http://localhost:3002/addEmail",
      // redirect_uri: "https://admin.leadingly.io/addEmail.html',
      redirect_uri: 'https://admin.b2brocket.ai/addEmail.html',
      javascript_origins: ['https://admin.leadingly.io', 'https://admin.b2brocket.ai'],
      scopes: [
        'https://mail.google.com/',
        'https://www.googleapis.com/auth/userinfo.profile',
        'https://www.googleapis.com/auth/userinfo.email',
        // "https://www.googleapis.com/auth/pubsub"
      ].join(' '),
    },
    microsoftWebAppConfig: {
      microsoft_api_url: 'https://graph.microsoft.com/beta',
      token_url: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
      client_id: '54459724-7cda-4eae-96a0-57adbc5cf289', //b2b
      client_secret: 'oxh8Q~oYfmxtSWz7P~p0C3pxgi32yljZ1XMpxagD', //b2b
      // redirect_uris: [
      //   'http://localhost:3002/addEmail',
      //   'https://admin.leadingly.io/addEmail.html',
      //   'https://admin.b2brocket.ai/addEmail.html',
      // ],
      //redirect_uri: "https://leadingly-testapp.vercel.app/dashboard/campaigns",
      redirect_uri: 'https://admin.b2brocket.ai/addEmail',
      //redirect_uri: 'http://localhost:3001/dashboard/campaigns',
      // redirect_uri: 'http://localhost:3000/addEmail',
      // redirect_uri: 'https://app.b2brocket.ai/dashboard/campaigns',
      redirect_uri1: 'https://app.b2brocket.ai/dashboard/campaigns',
      //redirect_uri1: 'http://localhost:3001/dashboard/campaigns',
      scopes: [
        'openid',
        'profile',
        'offline_access',
        "email",
        // "User.Read",
        'https://outlook.office.com/IMAP.AccessAsUser.All',
        'https://outlook.office.com/SMTP.Send',
      ].join(' '),
    },
  },

  ADD_TEST_LEADS: true,
  CACHING_ENABLED: true,
  // Augment a start date, ignore data before that
  SYS_STARTUP_AT: new Date('2023-09-26T00:00:00.000Z'),

  // ---------------------------Switch PRODUCTION / LOCAL------------------------------------------------
  // Also check line 4

  // // LOCAL
  // selfURL: 'http://localhost:8080',
  // EMAIL_SERVER: 'http://localhost:8085/api/v1/main',
  // CUSTOM_GPT_URL: 'http://127.0.0.1:5173/chat',

  // PRODUCTION
  selfURL: 'https://campaign-app-server-azure-pipeline.azurewebsites.net',
  EMAIL_SERVER: 'https://campaign-email-service-azure-devops.azurewebsites.net/api/v1/main',
  CUSTOM_GPT_URL: `${frontEndURL}/chat`,
  stripeRedirectUrl: frontEndURL,

  // CUSTOM_GPT_URL: 'https://react-sales-agent.vercel.app/chat',
  // CUSTOM_GPT_URL: 'http://www.brandheroes.io/chat',

  // EMAIL_SERVER:
  // 'https://campaign-email-service-16e74e4353e9.herokuapp.com/api/v1/main',

  // ----------------------------------------------------------------------------------------------------

  // Azure
  // CUSTOM_GPT_URL: 'https://lively-smoke-0529ef710.3.azurestaticapps.net/chat',

  // Vercel
  // CUSTOM_GPT_URL: 'https://react-sales-agent.vercel.app/chat',

  cronofy: {
    redirect_uri: frontEndURL,
    client_id: process.env.CRONOFY_CLIENT_ID,
    client_secret: process.env.CRONOFY_CLIENT_SECRET,
    // sub: 'acc_64a4f90c4359010594c8f1fc',
    data_center: 'us',
  },

  hubspot: {
    // redirect_uri: 'https://leadingly-admin-backend.azurewebsites.net/api/v1/main',
    redirect_uri: 'https://leadinglyapi.herokuapp.com/api/v1/main',
    client_id: process.env.HUBSPOT_CLIENT_ID,
    client_secret: process.env.HUBSPOT_CLIENT_SECRET,
  },

  logger: {
    error: (txt) => console.log(`${txt}`.red.bold),
    warning: (txt) => console.log(`${txt}`.yellow.bold),
    success: (txt) => console.log(`${txt}`.green.bold),
    focus: (txt) => console.log(`${txt}`.blue.bold),
  },
  API_SERVICE_BACKEND,
  API_ADMIN_SERVICE_BACKEND,
};
