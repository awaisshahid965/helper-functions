require('colors');
const mongoose = require('mongoose');

const mongoURI = process.env.MONGO_URI ?? '';

let connection = null;

async function connect() {
    if (!connection) {
        console.log('creating new mongodb connection!'.yellow);
        try {
            connection = await mongoose.connect(mongoURI, {
                useNewUrlParser: true,
                useUnifiedTopology: true,
                // poolSize: 10, // Connection pool size
            });

            console.log('MongoDB connected'.green.bold)
        } catch(err) {
            console.error('MongoDB connection error:', err)
        }
    }
    
    return connection;
}

module.exports = connect;
